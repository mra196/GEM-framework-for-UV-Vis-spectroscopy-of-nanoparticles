% This script generates all the plots in the manuscript, either in the main text or in the supplementary information.
%
% This script is part of the MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling"
% developed by M. Reza Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
% Please cite our article:
% M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".
% 
% % Add path to all necessary folders
% addpath(genpath('...\paperGNP_Andalibi_et_al_MATLAB'));
% % Set the directory
% cd '...\paperGNP_Andalibi_et_al_MATLAB'
% % Load the file that contains regressions of the seeds and grown GNP spectra
% load('...\input_output\EXP_15-85_70''C\fit_GEM_refined.mat')
%
%% Select between the two models (Gans and GEM)
% Initialize the selected output variables
r_GNP_temporal = zeros(numbTimeSteps,1);
beta_temporal = zeros(numbTimeSteps,1);
x_SC_temporal = nan(numbTimeSteps,1);
fillFact_temporal = nan(numbTimeSteps,1);
r_SC_temporal = nan(numbTimeSteps,1);
deviation_temporal = zeros(numbTimeSteps,1);
exitflag_temporal = zeros(numbTimeSteps,1);
concGNP_nM_temporal = zeros(numbTimeSteps,1);
concGNP_ppm_temporal = zeros(numbTimeSteps,1);
concSC_nM_temporal = nan(numbTimeSteps,1);
GNPperSC_temporal = nan(numbTimeSteps,1);
d_CC_temporal = nan(numbTimeSteps,1);
Abs_calc_temporal = zeros(length(lambdaFloorPlot:lambdaStep:lambdaCeilPlot),numbTimeSteps);
ciNeg_temporal = nan(numbTimeSteps,12);
ciPos_temporal = nan(numbTimeSteps,12);

for jj=1:numbTimeSteps
    if jj==1 || jj==numbTimeSteps || ... % The Gans model is selected if its r_GNP and beta are within 1% of that of the GEM model
            ((abs(r_GNP_noninteract(jj)-r_GNP_GEM(jj))/r_GNP_GEM(jj) <= 0.01) && (abs(beta_noninteract(jj)-beta_GEM(jj))/beta_GEM(jj) <= 0.01))
        r_GNP_temporal(jj) = r_GNP_noninteract(jj);
        beta_temporal(jj) = beta_noninteract(jj);
        deviation_temporal(jj) = deviation_noninteract(jj);
        exitflag_temporal(jj) = exitflag_noninteract(jj);
        concGNP_nM_temporal(jj) = concGNP_nM_noninteract(jj);
        concGNP_ppm_temporal(jj) = concGNP_ppm_noninteract(jj);
        Abs_calc_temporal(:,jj) = Abs_calc_noninteract(:,jj);
        d_CC_temporal(jj) = inf;
        ciNeg_temporal(jj,1:2) = ciNeg_noninteract(jj,1:2);
        ciNeg_temporal(jj,6:7) = ciNeg_noninteract(jj,3:4);
        ciPos_temporal(jj,1:2) = ciPos_noninteract(jj,1:2);
        ciPos_temporal(jj,6:7) = ciPos_noninteract(jj,3:4);
    else
        r_GNP_temporal(jj) = r_GNP_GEM(jj);
        beta_temporal(jj) = beta_GEM(jj);
        x_SC_temporal(jj) = x_SC(jj);
        fillFact_temporal(jj) = fillFact(jj);
        r_SC_temporal(jj) = r_SC(jj);
        deviation_temporal(jj) = deviation_GEM(jj);
        exitflag_temporal(jj) = exitflag_GEM(jj);
        concGNP_nM_temporal(jj) = concGNP_nM_GEM(jj);
        concGNP_ppm_temporal(jj) = concGNP_ppm_GEM(jj);
        concSC_nM_temporal(jj) = concSC_nM(jj);
        GNPperSC_temporal(jj) = GNPperSC(jj);
        Abs_calc_temporal(:,jj) = Abs_calc_GEM(:,jj);
        d_CC_temporal(jj) = d_CC(jj);
        ciNeg_temporal(jj,:) = ciNeg_GEM(jj,:);
        ciPos_temporal(jj,:) = ciPos_GEM(jj,:);
    end
end

% Replace zeros in the GEM fit output with nan (spectra without GEM fit which are presumably the first and the last one)
r_GNP_GEM(r_GNP_GEM==0) = nan;
beta_GEM(beta_GEM==0) = nan;
x_SC(x_SC==0) = nan;
fillFact(fillFact==0) = nan;
r_SC(r_SC==0) = nan;
x_SC_temporal(x_SC_temporal==0) = nan;
fillFact_temporal(fillFact_temporal==0) = nan;
r_SC_temporal(r_SC_temporal==0) = nan;
deviation_GEM(deviation_GEM==0) = nan;
concGNP_nM_GEM(concGNP_nM_GEM==0) = nan;
concGNP_ppm_GEM(concGNP_ppm_GEM==0) = nan;
concSC_nM(concSC_nM==0) = nan;
GNPperSC(GNPperSC==0) = nan;

%% Linear relation for concGNP_ppm from Abs_400 and density estimation
% Calibrate using seeds and grown GNP which have known concGNP_ppm (the density for these two can be assumed to be that of the bulk, 19.3 g/cm3)
i400 = find(lambda>=400,1);
X = [ones(3,1), [0;mean(Abs(i400-1:i400+1,1)); mean(Abs(i400-1:i400+1,end))]];
Y = [0; concGNP_ppm_noninteract(1); concGNP_ppm_noninteract(end)];
bConc = X\Y;
% Use the linear relation to obtain all the temporal concGNP_ppm
concGNP_ppm_Abs400 = (bConc(1)+bConc(2)*mean(Abs(i400-1:i400+1,:),1))';
% Back-calculate the GNP density by comparing the actual concentration (concGNP_ppm_Abs400) to that estimated assuming a density of 19.3
particleDensity = 19.3*concGNP_ppm_Abs400./concGNP_ppm_temporal; % g/cm3
% Estimate the corresponding 95% CI
ciNeg_particleDensity = particleDensity-19.3*concGNP_ppm_Abs400./(concGNP_ppm_temporal+ciPos_temporal(:,7));
ciPos_particleDensity = 19.3*concGNP_ppm_Abs400./(concGNP_ppm_temporal-ciNeg_temporal(:,7))-particleDensity;

%% A_spr, lambda_spr and PWHM from experimental spectra
[Abs_spr,i_spr] = max(Abs(i400:end,:),[],1);
i_spr = i_spr+i400-1;
PWHM = zeros(size(Abs,2),1);
parfor jj=1:size(Abs,2)
    iHM = find(Abs(i_spr(jj):end,jj)<=Abs_spr(jj)/2,1)+i_spr(jj)-1;
    PWHM(jj) = 2*(lambda(iHM)-lambda(i_spr(jj)));
end

%% Time regios for shading the plots
patchTime = [0 150 350 590 750 time(end)]; % 15:85-70'C
clr = ones(length(patchTime)-1,3) .* linspace(0.65,1,length(patchTime)-1)';

%% Plot the optimal parameters
subplot = @(m,n,p) subtightplot (m, n, p, [0.08 0.01], [0.08 0.02], [0.1 0.1]);

pos = [0.95, 0.9, 1]; % where to put a, b, ... for each diagram

figure('Color','white')
ax = subplot(2,3,1); %-----------------------------------------------------------------------------%
errorbar(time,r_GNP_temporal,ciNeg_temporal(:,1),ciPos_temporal(:,1),'k.','CapSize',4); hold on;
plot(time,r_GNP_GEM,'ro','MarkerSize',4);
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,r_GNP_temporal,ciNeg_temporal(:,1),ciPos_temporal(:,1),'k.','CapSize',4); hold on;
plot(time,r_GNP_GEM,'ro','MarkerSize',4); hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$\bar{r}_{GNP} (nm)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
ylim([2*floor(min(r_GNP_temporal)/2),2*ceil(max(r_GNP_temporal)/2)])
line([0 0], ylim,'Color','black');  %y-axis
line(xlim, [min(ylim) min(ylim)],'Color','black');  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'a','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
for iReg=2:length(patchTime)
    text(0.5*(patchTime(iReg)+patchTime(iReg-1)),0.98*max(ylim),['(',num2roman(iReg-1),')'],...
        'FontSize',12,'FontWeight','bold','HorizontalAlignment','center')
end
legend({'$Selected$','$GEM$'},'Interpreter','Latex','FontSize',16,'FontWeight','bold','Location','southeast')
ax = subplot(2,3,2); %-----------------------------------------------------------------------------%
errorbar(time,beta_temporal,ciNeg_temporal(:,2),ciPos_temporal(:,2),'k.','CapSize',4); hold on;
plot(time,beta_GEM,'ro','MarkerSize',4); hold on;
ylim([1,0.2*ceil(max(beta_temporal)/0.2)])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,beta_temporal,ciNeg_temporal(:,2),ciPos_temporal(:,2),'k.','CapSize',4); hold on;
plot(time,beta_GEM,'ro','MarkerSize',4); hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$\bar{\beta}$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([0 0], ylim,'Color','black');  %y-axis
line(xlim, [1 1]);  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'b','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
ax = subplot(2,3,3); %-----------------------------------------------------------------------------%
errorbar(time,x_SC_temporal,ciNeg_temporal(:,3),ciPos_temporal(:,3),'k.','CapSize',4); hold on;
ylim(10.^[floor(min(log10(x_SC_temporal-ciNeg_temporal(:,3)))),ceil(max(log10(x_SC_temporal+ciPos_temporal(:,3))))])
set(gca,'YScale','log');
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,x_SC_temporal,ciNeg_temporal(:,3),ciPos_temporal(:,3),'k.','CapSize',4); hold on;
hold off;
set(gca,'YScale','log');
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$x_{SC}$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([0 0], ylim,'Color','black');  %y-axis
line(xlim, [0 0],'Color','black');  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'c','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
h = text(0.5*(patchTime(end)+patchTime(end-1)),min(ylim)+(max(ylim)-min(ylim))*0.007,{'$No$ $particle-particle$','$interaction$ $effects!$'},...
        'Interpreter','latex','FontSize',16,'FontWeight','bold','Color','red','HorizontalAlignment','center','VerticalAlignment','middle');
set(h,'Rotation',270);
ax = subplot(2,3,4); %-----------------------------------------------------------------------------%
errorbar(time,fillFact_temporal,ciNeg_temporal(:,4),ciPos_temporal(:,4),'k.','CapSize',4); hold on;
ylim([0,0.4])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,fillFact_temporal,ciNeg_temporal(:,4),ciPos_temporal(:,4),'k.','CapSize',4); hold on;
hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$f$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([0 0], ylim,'Color','black');  %y-axis
line(xlim, [0 0],'Color','black');  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'d','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
h = text(0.5*(patchTime(end)+patchTime(end-1)),min(ylim)+(max(ylim)-min(ylim))*0.5,{'$No$ $particle-particle$','$interaction$ $effects!$'},...         'Interpreter','latex','FontSize',16,'FontWeight','bold','Color','red','HorizontalAlignment','center','VerticalAlignment','middle');
        'Interpreter','latex','FontSize',16,'FontWeight','bold','Color','red','HorizontalAlignment','center');
set(h,'Rotation',270);
ax = subplot(2,3,5); %-----------------------------------------------------------------------------%
errorbar(time,r_SC_temporal,ciNeg_temporal(:,5),ciPos_temporal(:,5),'k.','CapSize',4); hold on;
ylim([50*floor(min(r_SC_temporal-ciNeg_temporal(:,5))/50),300])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,r_SC_temporal,ciNeg_temporal(:,5),ciPos_temporal(:,5),'k.','CapSize',4); hold on;
hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$\bar{r}_{SC} (nm)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([0 0], ylim,'Color','black');  %y-axis
line(xlim, [min(ylim) min(ylim)],'Color','black');  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'e','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
h = text(0.5*(patchTime(end)+patchTime(end-1)),min(ylim)+(max(ylim)-min(ylim))*0.5,{'$No$ $particle-particle$','$interaction$ $effects!$'},...         'Interpreter','latex','FontSize',16,'FontWeight','bold','Color','red','HorizontalAlignment','center','VerticalAlignment','middle');
        'Interpreter','latex','FontSize',16,'FontWeight','bold','Color','red','HorizontalAlignment','center');
set(h,'Rotation',270);
ax = subplot(2,3,6); %-----------------------------------------------------------------------------%
errorbar(time,concGNP_nM_temporal*6.022e14,ciNeg_temporal(:,6)*6.022e14,ciPos_temporal(:,6)*6.022e14,'k.','CapSize',4); hold on;
plot(time,concGNP_nM_GEM*6.022e14,'ro','MarkerSize',4); hold on;
ylim([0,1e15*ceil(6.022e14*max(concGNP_nM_temporal+ciPos_temporal(:,6))/1e15)])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,concGNP_nM_temporal*6.022e14,ciNeg_temporal(:,6)*6.022e14,ciPos_temporal(:,6)*6.022e14,'k.','CapSize',4); hold on;
plot(time,concGNP_nM_GEM*6.022e14,'ro','MarkerSize',4); hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$GNP$ $concentration$ $(particles/L)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([min(xlim) min(xlim)], [min(ylim) max(ylim)]);  %y-axis
line(xlim, [min(ylim) min(ylim)],'Color','black');  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'f','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)

maximize
imagewd = getframe(gcf);
imwrite(imagewd.cdata, 'Fig1.tiff','Compression','none','Resolution',600);

%% Plot other regression outputs, Eh_pH, and raw spectral features
subplot = @(m,n,p) subtightplot (m, n, p, [0.08 0.08], [0.1 0.03], [0.1 0.1]);

pos = [0.95, 0.03, 1];

figure('Color','white')
ax = subplot(2,3,1); %-----------------------------------------------------------------------------%
yyaxis left
plot(time,concGNP_ppm_Abs400/197,'o','MarkerSize',4); hold on
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
yyaxis left
plot(time,concGNP_ppm_Abs400/197,'o','MarkerSize',4);
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$GNP$ $concentration$ $(mM$ $Au(0))$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylim([0.1,0.4])
line([0 0], [min(ylim) max(ylim)]); hold off; %y-axis
yyaxis right
errorbar(time,particleDensity,ciNeg_particleDensity,ciPos_particleDensity,'.','CapSize',3); hold off
ylabel('$GNP$ $density$ $(g/cm^3)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'a','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
for iReg=2:length(patchTime)
    text(0.5*(patchTime(iReg)+patchTime(iReg-1)),0.995*max(ylim),['(',num2roman(iReg-1),')'],...
        'FontSize',12,'FontWeight','bold','HorizontalAlignment','center')
end
ax = subplot(2,3,2); %-----------------------------------------------------------------------------%
errorbar(time,percGNPinSC,ciNeg_GEM(:,10),ciPos_GEM(:,10),'k.','CapSize',4); hold on;
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,percGNPinSC,ciNeg_GEM(:,10),ciPos_GEM(:,10),'k.','CapSize',4); hold on;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$\%$ $GNPs$ $inside$ $superclusters$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'b','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
h = text(0.5*(patchTime(end)+patchTime(end-1)),min(ylim)+(max(ylim)-min(ylim))*0.4,{'$No$ $particle-particle$','$interaction$ $effects!$'},...         'Interpreter','latex','FontSize',16,'FontWeight','bold','Color','red','HorizontalAlignment','center','VerticalAlignment','middle');
        'Interpreter','latex','FontSize',16,'FontWeight','bold','Color','red','HorizontalAlignment','center');
set(h,'Rotation',270);
ax = subplot(2,3,3); %-----------------------------------------------------------------------------%
yyaxis left
errorbar(time,d_CC_temporal./r_GNP_temporal,ciNeg_temporal(:,12),ciPos_temporal(:,12),'s','CapSize',4); hold on
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,d_CC_temporal./r_GNP_temporal,ciNeg_temporal(:,12),ciPos_temporal(:,12),'s','CapSize',4)
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$\bar{d}_{CC}/\bar{r}_{GNP}$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
line([0 0], [min(ylim) max(ylim)]); hold off; %y-axis
yyaxis right
errorbar(time,d_CC_temporal,ciNeg_temporal(:,11),ciPos_temporal(:,11),'o','CapSize',4); hold on;
ylabel('$\bar{d}_{CC}$ $(nm)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([max(xlim) max(xlim)], [min(ylim) max(ylim)]); hold off; %y-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'c','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
h = text(0.5*(patchTime(end)+patchTime(end-1)),min(ylim)+(max(ylim)-min(ylim))*0.6,{'$No$ $particle-particle$','$interaction$ $effects!$'},...
        'Interpreter','latex','FontSize',16,'FontWeight','bold','Color','red','HorizontalAlignment','center');
set(h,'Rotation',270);
ax = subplot(2,3,4); %-----------------------------------------------------------------------------%
if length(patchTime)==6
    clrAbs = [rgb('Gray'); rgb('DarkBlue'); rgb('Purple'); rgb('Indigo'); rgb('DarkMagenta');...
        rgb('Magenta'); rgb('Thistle'); rgb('PaleVioletRed'); rgb('MediumVioletRed');...
        rgb('Salmon'); rgb('Red');rgb('Crimson')];
else
    clrAbs = [rgb('Gray'); rgb('DarkBlue'); rgb('Purple'); rgb('Indigo'); rgb('DarkMagenta');...
    rgb('Thistle'); rgb('PaleVioletRed'); rgb('MediumVioletRed');...
    rgb('Salmon');rgb('Crimson')]; % For 0:100-70'C data
end
subpltTime = sort([time(2), patchTime,(patchTime(1:end-1)+patchTime(2:end))/2]);
for ii=1:length(clrAbs)
    jj = find(time-subpltTime(ii)>=0,1);
    plot(lambda,Abs(:,jj),'-','color',clrAbs(ii,:),'LineWidth',1.75); hold on;
end
xlabel('$\lambda$ $(nm)$','Interpreter','Latex','FontSize',12,'FontWeight','bold')
ylabel('$Extinction$ $(a.u.)$','Interpreter','Latex','FontSize',12,'FontWeight','bold');
xlim([400,800])
legend(cellstr(string(subpltTime)),'FontSize',10,'FontWeight','bold','Location','northeast');
axis square
box on
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
hold off
title(ax,'d','FontSize',16,'FontWeight','bold','Units','normalized','Position',[0.05, 0.02, 1])
ax = subplot(2,3,5); %-----------------------------------------------------------------------------%
plot(time,PWHM,'ko','MarkerFaceColor','k','MarkerSize',4); hold on;
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
plot(time,PWHM,'ko','MarkerFaceColor','k','MarkerSize',4); hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$PWHM$ $(nm)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
xlim([0,500*ceil(time(end)/500)])
line([0 0], ylim,'Color','black');  %y-axis
line(xlim, [min(ylim) min(ylim)],'Color','black');  %x-axis
axis square
box off
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'e','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
ax = subplot(2,3,6); %-----------------------------------------------------------------------------%
yyaxis left
plot(timeTiamo,Eh,'.'); hold on;
xlim([50*floor(timeTiamo(1)/50),500*ceil(timeTiamo(end)/500)])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
yyaxis left
plot(timeTiamo,Eh,'.')
line([min(xlim) min(xlim)], [min(ylim) max(ylim)]); hold off; %y-axis
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$Eh$ $(mV)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
yyaxis right
plot(timeTiamo,pH,'.'); hold on;
ylim([0.5*floor(min(pH)/0.5),0.5*ceil(max(pH)/0.5)])
line([500*ceil(timeTiamo(end)/500) 500*ceil(timeTiamo(end)/500)], [min(ylim) max(ylim)]); hold off; %y-axis
ylabel('$pH$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
line(xlim, [min(ylim) min(ylim)],'Color','black');  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'f','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)

maximize
imagewd = getframe(gcf);
imwrite(imagewd.cdata, 'Fig2.tiff','Compression','none','Resolution',600);

%% Plot deviations
subplot = @(m,n,p) subtightplot (m, n, p, [0.07 0.07], [0.07 0.02], [0.05 0.05]);
pos = [0.95, 0.9, 1];

figure('Color','white');
ax = subplot(1,2,1); %-------------------------------------------------------------------------------------------------%
plot(time,100*deviation_temporal,'ko',time,100*deviation_GEM,'r.',time,100*deviation_noninteract,'bs'); hold on
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
plot(time,100*deviation_temporal,'ko',time,100*deviation_GEM,'r.',time,100*deviation_noninteract,'bs');
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$Range-normalized$ $RMSE$ $(\%)$','Interpreter','Latex','FontSize',18,'FontWeight','bold')
legend({'Selected model','GEM','Noninteracting GNPs'},'FontSize',18,'FontWeight','bold','location','east')
axis square
xlim([0,500*ceil(time(end)/500)])
set(ax,'FontSize',18,'FontWeight','bold');
for iReg=2:length(patchTime)
    text(0.5*(patchTime(iReg)+patchTime(iReg-1)),0.9*max(ylim),['(',num2roman(iReg-1),')'],...
        'FontSize',18,'FontWeight','bold','HorizontalAlignment','center')
end
title(ax,'a','FontSize',18,'FontWeight','bold','Units','normalized','Position',pos)
ax = subplot(1,2,2); %-------------------------------------------------------------------------------------------------%
plot(lambda,100*(Abs-Abs_calc_temporal)./(max(Abs(i400:end,:),[],1)-min(Abs(i400:end,:),[],1)),'.')
xlabel('$\lambda$ $(nm)$','Interpreter','Latex','FontSize',18,'FontWeight','bold')
ylabel('$100\times(Abs_{exp}-Abs_{calc})/(Abs_{spr}-Abs_{min})$ $(\%)$','Interpreter','Latex','FontSize',18,'FontWeight','bold')
axis square
xlim([400,800])
set(ax,'FontSize',18,'FontWeight','bold');
title(ax,'b','FontSize',18,'FontWeight','bold','Units','normalized','Position',pos)

maximize
imagewd = getframe(gcf);
imwrite(imagewd.cdata, 'Fig3.tiff','Compression','none','Resolution',600);

%% Plot temporal fits in regional points
subplot = @(m,n,p) subtightplot (m, n, p, [0.1 0.01], [0.07 0.03], [0.2 0.2]);

figure('Color','white')
rowSubPlot = 3;
colSubPlot = 4;
ax = subplot(rowSubPlot,colSubPlot,1); %----------------------------------------------------------------------------------%
plot(lambda,Abs(:,1),'ro'); hold on;
plot((200:800)',Abs_calc_temporal(:,1),'k-','LineWidth',2); hold off;
xlabel('$\lambda$ $(nm)$','Interpreter','Latex','FontSize',14,'FontWeight','bold')
ylabel('$Extinction$ $(a.u.)$','Interpreter','Latex','FontSize',14,'FontWeight','bold');
title([sprintf('t = %.0f', time(1)), ' sec'],'FontSize',14,'FontWeight','bold')
xlim([400,800])
ax.Box = 'off';
axis square
set(ax,'FontSize',14,'FontWeight','bold');
ax = subplot(rowSubPlot,colSubPlot,2); %----------------------------------------------------------------------------------%
plot(lambda,Abs(:,2),'ro'); hold on;
plot((200:800)',Abs_calc_temporal(:,2),'k-','LineWidth',2); hold off;
xlabel('$\lambda$ $(nm)$','Interpreter','Latex','FontSize',14,'FontWeight','bold')
ylabel('$Extinction$ $(a.u.)$','Interpreter','Latex','FontSize',14,'FontWeight','bold');
title([sprintf('t = %.0f', time(2)), ' sec'],'FontSize',14,'FontWeight','bold')
xlim([400,800])
% ylim([0,1.5])
ax.Box = 'off';
axis square
set(ax,'FontSize',14,'FontWeight','bold');
subpltTime = sort([patchTime,(patchTime(1:end-1)+patchTime(2:end))/2]); %----------------------------------------------------------------------------------%
for jj=3:length(clrAbs)
    ax = subplot(rowSubPlot,colSubPlot,jj);
    jj = find(time-subpltTime(jj-1)>=0);
    jj = jj(1);
    plot(lambda,Abs(:,jj),'ro'); hold on;
    plot((200:800)',Abs_calc_temporal(:,jj),'k-','LineWidth',2); hold off;
    xlabel('$\lambda$ $(nm)$','Interpreter','Latex','FontSize',14,'FontWeight','bold')
    ylabel('$Extinction$ $(a.u.)$','Interpreter','Latex','FontSize',14,'FontWeight','bold');
    title([sprintf('t = %.0f', time(jj)), ' sec'],'FontSize',14,'FontWeight','bold')
    xlim([400,800])
%     ylim([0,1.5])
    ax.Box = 'off';
    axis square
    set(ax,'FontSize',14,'FontWeight','bold');
end

maximize
imagewd = getframe(gcf);
imwrite(imagewd.cdata, 'Fig4.tiff','Compression','none','Resolution',600);

%% Uncomment to plot all the temporal fits
% jjFirstPlot = 1;
% jjLastPlot = 0;
% figCounter = 0;
% while jjLastPlot < numbTimeSteps
%     rowSubPlot = 4;
%     colSubPlot = 8;
%     numbSubPlots = rowSubPlot*colSubPlot;
%     
%     jjFirstPlot = 1 + figCounter*numbSubPlots;
%     jjLastPlot = jjFirstPlot + numbSubPlots - 1;
% 
%     subplot = @(m,n,p) subtightplot (m, n, p, [0.1 0.002], [0.06 0.04], [0.02 0.001]);
%     figure('Color','white')
%     subplotIndex = 1;
%     for jj=jjFirstPlot:min(jjFirstPlot+numbSubPlots-1,numbTimeSteps)
%         ax = subplot(rowSubPlot,colSubPlot,subplotIndex);
%         plot(lambda,Abs(:,jj),'ro'); hold on;
%         plot((200:800)',Abs_calc_temporal(:,jj),'k-','LineWidth',2); hold off;
%         xlabel('$\lambda$ $(nm)$','Interpreter','Latex','FontSize',12,'FontWeight','bold')
%         ylabel('$Extinction$ $(a.u.)$','Interpreter','Latex','FontSize',12,'FontWeight','bold');
%         title([sprintf('t = %.0f', time(jj)), ' sec'],'FontSize',12,'FontWeight','bold')
%         xlim([400,800])
%         ylim([0,1.5])
%         ax.Box = 'off';
%         axis square
%         set(ax,'FontSize',12,'FontWeight','bold');
% 
%         subplotIndex = subplotIndex+1;
%     end
% 
%     maximize
%     imagewd = getframe(gcf);
%     imwrite(imagewd.cdata, ['Fig',num2str(4+figCounter+1),'.tiff'],'Compression','none','Resolution',300);
%     
%     figCounter = figCounter+1;
% end

%% Convergence of GEM and Gans common parameters
particleDensity_GEM = 19.3*concGNP_ppm_Abs400./concGNP_ppm_GEM; % g/cm3
ciNeg_particleDensity_GEM = particleDensity_GEM-19.3*concGNP_ppm_Abs400./(concGNP_ppm_GEM+ciPos_GEM(:,7));
ciPos_particleDensity_GEM = 19.3*concGNP_ppm_Abs400./(concGNP_ppm_GEM-ciNeg_GEM(:,7))-particleDensity_GEM;

particleDensity_noninteract = 19.3*concGNP_ppm_Abs400./concGNP_ppm_noninteract; % g/cm3
ciNeg_particleDensity_noninteract = particleDensity_noninteract-19.3*concGNP_ppm_Abs400./(concGNP_ppm_noninteract+ciPos_noninteract(:,4));
ciPos_particleDensity_noninteract = 19.3*concGNP_ppm_Abs400./(concGNP_ppm_noninteract-ciNeg_noninteract(:,4))-particleDensity_noninteract;

subplot = @(m,n,p) subtightplot (m, n, p, [0.1 0.01], [0.08 0.02], [0.25 0.25]);

pos = [0.95, 0.02, 1];

figure('Color','white')
ax = subplot(2,2,1); %-----------------------------------------------------------------------------%
errorbar(time,r_GNP_noninteract,ciNeg_noninteract(:,1),ciPos_noninteract(:,1),'k.','CapSize',4); hold on;
errorbar(time,r_GNP_GEM,ciNeg_GEM(:,1),ciPos_GEM(:,1),'ro','MarkerSize',4,'CapSize',4);
ylim([2*floor(min([r_GNP_temporal;r_GNP_noninteract])/2),2*ceil(max([r_GNP_temporal;r_GNP_noninteract])/2)])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,r_GNP_noninteract,ciNeg_noninteract(:,1),ciPos_noninteract(:,1),'k.','CapSize',4); hold on;
errorbar(time,r_GNP_GEM,ciNeg_GEM(:,1),ciPos_GEM(:,1),'ro','MarkerSize',4,'CapSize',4); hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$\bar{r}_{GNP} (nm)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([0 0], ylim,'Color','black');  %y-axis
line(xlim, [min(ylim) min(ylim)],'Color','black');  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'a','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
for iReg=2:length(patchTime)
    text(0.5*(patchTime(iReg)+patchTime(iReg-1)),0.98*max(ylim),['(',num2roman(iReg-1),')'],...
        'FontSize',12,'FontWeight','bold','HorizontalAlignment','center')
end
legend({'$Gans$','$GEM$'},'Interpreter','Latex','FontSize',16,'FontWeight','bold','Location','east')
ax = subplot(2,2,2); %-----------------------------------------------------------------------------%
errorbar(time,beta_noninteract,ciNeg_noninteract(:,2),ciPos_noninteract(:,2),'k.','CapSize',4); hold on;
errorbar(time,beta_GEM,ciNeg_GEM(:,2),ciPos_GEM(:,2),'ro','MarkerSize',4,'CapSize',4);
ylim([1,0.2*ceil(max([beta_temporal;beta_noninteract])/0.2)])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,beta_noninteract,ciNeg_noninteract(:,2),ciPos_noninteract(:,2),'k.','CapSize',4); hold on;
errorbar(time,beta_GEM,ciNeg_GEM(:,2),ciPos_GEM(:,2),'ro','MarkerSize',4,'CapSize',4); hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$\bar{\beta}$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([0 0], ylim,'Color','black');  %y-axis
line(xlim, [1 1]);  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'b','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
ax = subplot(2,2,3); %-----------------------------------------------------------------------------%
errorbar(time,concGNP_nM_noninteract*6.022e14,ciNeg_noninteract(:,3)*6.022e14,ciPos_noninteract(:,3)*6.022e14,'k.','CapSize',4); hold on;
errorbar(time,concGNP_nM_GEM*6.022e14,ciNeg_GEM(:,6)*6.022e14,ciPos_GEM(:,6)*6.022e14,'ro','MarkerSize',4,'CapSize',4);
ylim([0,1e16*ceil(6.022e14*max([concGNP_nM_temporal+ciPos_temporal(:,6);concGNP_nM_noninteract+ciPos_noninteract(:,3)])/1e16)])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,concGNP_nM_noninteract*6.022e14,ciNeg_noninteract(:,3)*6.022e14,ciPos_noninteract(:,3)*6.022e14,'k.','CapSize',4); hold on;
errorbar(time,concGNP_nM_GEM*6.022e14,ciNeg_GEM(:,6)*6.022e14,ciPos_GEM(:,6)*6.022e14,'ro','MarkerSize',4,'CapSize',4); hold off;
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
ylabel('$GNP$ $concentration$ $(particles/L)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
axis square
ax.Box = 'off';
xlim([0,500*ceil(time(end)/500)])
line([min(xlim) min(xlim)], [min(ylim) max(ylim)]);  %y-axis
line(xlim, [min(ylim) min(ylim)],'Color','black');  %x-axis
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'c','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)
ax = subplot(2,2,4); %-----------------------------------------------------------------------------%
errorbar(time,particleDensity_noninteract,ciNeg_particleDensity_noninteract,ciPos_particleDensity_noninteract,'k.','CapSize',4); hold on;
errorbar(time,particleDensity_GEM,ciNeg_particleDensity_GEM,ciPos_particleDensity_GEM,'ro','MarkerSize',4,'CapSize',4); hold on;
ylim([floor(min([particleDensity_noninteract-ciNeg_particleDensity_noninteract;particleDensity_GEM-ciNeg_particleDensity_GEM])),...
    ceil(max([particleDensity_noninteract+ciPos_particleDensity_noninteract;particleDensity_GEM-ciPos_particleDensity_GEM]))])
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
errorbar(time,particleDensity_noninteract,ciNeg_particleDensity_noninteract,ciPos_particleDensity_noninteract,'k.','CapSize',4);
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
errorbar(time,particleDensity_GEM,ciNeg_particleDensity_GEM,ciPos_particleDensity_GEM,'ro','MarkerSize',4,'CapSize',4); hold off;
ylabel('$Estimated$ $GNP$ $density$ $(g/cm^3)$','Interpreter','Latex','FontSize',16,'FontWeight','bold')
xlim([0,500*ceil(time(end)/500)])
line([min(xlim) min(xlim)], [min(ylim) max(ylim)]);  %y-axis
line(xlim, [min(ylim) min(ylim)],'Color','black');  %x-axis
axis square
ax.Box = 'off';
set(ax,'FontSize',16,'FontWeight','bold','TickDir','out');
title(ax,'d','FontSize',16,'FontWeight','bold','Units','normalized','Position',pos)

maximize
imagewd = getframe(gcf);
imwrite(imagewd.cdata, 'FigConvergence.tiff','Compression','none','Resolution',600);

%% Principal Component Analysis (PCA)
[coeff,score,latent,tsquared,explained,mu] = pca(Abs(i400:end,:)');

subplot = @(m,n,p) subtightplot (m, n, p, [0.07 0.07], [0.07 0.02], [0.07 0.07]);

pos = [0.95, 0.02, 1];

figure('Color','white');
ax = subplot(1,2,1); %--------------------------------------------------------------------------------------------------------------------%
h = plot((400:800)',coeff(:,1:4),'.','MarkerSize',20);
set(h, {'color'}, {rgb('Crimson');rgb('Grey');rgb('BlueViolet');rgb('Lime')});
xlabel('$\lambda$ $(nm)$','Interpreter','Latex','FontSize',18,'FontWeight','bold')
ylabel('$Principal$ $component$ $coefficient$','Interpreter','Latex','FontSize',18,'FontWeight','bold')
legend({'PC1','PC2','PC3','PC4'},'Interpreter','Latex','FontSize',18,'FontWeight','bold')
axis square
box on
set(ax,'FontSize',18,'FontWeight','bold','TickDir','out');
title(ax,'a','FontSize',18,'FontWeight','bold','Units','normalized','Position',pos)
ax = subplot(1,2,2); %--------------------------------------------------------------------------------------------------------------------%
plot(time,score(:,1:4)','.','MarkerSize',20); hold on;
for iReg = 1:length(patchTime)-2
    patch([patchTime(iReg) patchTime(iReg+1) patchTime(iReg+1) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
end
iReg = iReg+1;
patch([patchTime(iReg) max(xlim) max(xlim) patchTime(iReg)], [max(ylim) max(ylim) min(ylim) min(ylim)], clr(iReg,:), 'EdgeColor', 'none')
h = plot(time,score(:,1:4)','.','MarkerSize',20);
ylim([-6,4])
set(h, {'color'}, {rgb('Crimson');rgb('Grey');rgb('BlueViolet');rgb('Lime')});
xlabel('$time$ $(sec)$','Interpreter','Latex','FontSize',18,'FontWeight','bold')
ylabel('$Principal$ $component$ $score$','Interpreter','Latex','FontSize',18,'FontWeight','bold')
axis square
box off
set(ax,'FontSize',18,'FontWeight','bold','TickDir','out');
line([0 0], [-6 4]);  %y-axis
line([0 500*ceil(time(end)/500)], [-6 -6],'Color','black');  %x-axis
title(ax,'b','FontSize',18,'FontWeight','bold','Units','normalized','Position',pos)
for iReg=2:length(patchTime)
    text(0.5*(patchTime(iReg)+patchTime(iReg-1)),0.85*max(ylim),['(',num2roman(iReg-1),')'],...
        'FontSize',18,'FontWeight','bold','HorizontalAlignment','center')
end

maximize
imagewd = getframe(gcf);
imwrite(imagewd.cdata, 'FigPCA.tiff','Compression','none','Resolution',600);
