function [c,ceq] = nonlcon_parEMT(x,r_GNP,lb,ub,minGNPperSC,maxGNPperSC )
% 
% This function exerts the nonlinear constraint in Supp. Eq. 13 where
% GNPperSC >= minGNPperSC. Optionally an upper bound could also be exerted.
% 
% Usage:
% [c,ceq] = nonlcon_parEMT(x,r_GNP,lb,ub,minGNPperSC,maxGNPperSC )
% Input:
%   x = optimization variables (e.g., [r_GNP,beta,x_SC,f,r_SC])
%   r_GNP = mean GNP radius (if it is fixed and not optimized)
%   lb = lower bound vector for optimization variables
%   ub = upper bound vector for optimization variables
%   minGNPperSC = minimum acceptable number of GNPs interacting inside a SC
%   maxGNPperSC = maximum acceptable number of GNPs interacting inside a SC (set equal to [] if there is none)
% Output:
%   c = nonlinear inequality constraint in the form c<=0
%   ceq = nonlinear equality constraint in the form (we don't have any here!)
%
% This function is part of the MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling"
% developed by M. Reza Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
% Please cite our article:
% M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".

% Expand lb and ub to the size of input optimization sets
lb = repmat(lb,size(x,1),1);
ub = repmat(ub,size(x,1),1);
% If r_GNP is not fixed and is being fitted the first column of x is r_GNP
if isempty(r_GNP)
    r_GNP = (x(:,1)+1).*(ub(:,1)-lb(:,1))/2 + lb(:,1); % Unscale and uncenter
end
% anti-log, unscale and uncenter fillFact and r_SC (x_SC is also the same but we don't need it here!)
x(:,end-1:end) = 10.^((x(:,end-1:end)+1).*(ub(:,end-1:end)-lb(:,end-1:end))/2 + lb(:,end-1:end));
% Nonlinear inequality constraint
if isempty(maxGNPperSC)
    c = minGNPperSC - x(:,end-1) .* (x(:,end)./r_GNP).^3;
else
    c(1) = minGNPperSC - x(:,end-1) .* (x(:,end)./r_GNP).^3;
    c(2) = x(:,end-1) .* (x(:,end)./r_GNP).^3 - maxGNPperSC;
end
% We have no nonlinear equaility constraint!
ceq = [];