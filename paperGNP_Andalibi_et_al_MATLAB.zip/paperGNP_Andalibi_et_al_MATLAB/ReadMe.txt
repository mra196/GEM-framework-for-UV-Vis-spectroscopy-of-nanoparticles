MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling" developed by M. Reza  Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
Please cite our article: arXiv:1903.06206 [cond-mat.mtrl-sci]
M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".

The sequence starting from raw intensity signals to final kinetic outputs is as follows:
1) spectraTreatment
2) optimSeedsGrown
3) optimNoninteract
4) optimGEM
5) paperFigs

Step-by-step guidance is provided in the form of comments throughout the scripts and codes.

Please contact us for any further questions.