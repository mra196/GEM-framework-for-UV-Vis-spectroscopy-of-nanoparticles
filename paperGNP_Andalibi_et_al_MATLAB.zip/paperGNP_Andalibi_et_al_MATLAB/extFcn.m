function [deviation,Abs_calc,concGNP_nM,concGNP_ppm,concSC_nM] = ... 
    extFcn(lambda,Abs,T,r_GNP,polydisp,beta,beta_CV,eta0,etaCoeff,parA,...
    x_SC,fillFact,r_SC,lu_bounds,fixedParFlag,plotFlag,lambdaFloor,lambdaCeil,sizeDepRealEpsFlag,dielectricFcn,parFvalSaveAddress)
% 
% This function calculates the extinction of light by suspensions of prolate-shaped gold
% nanopartilces (GNPs) either in the absence or presence of
% electromagnetic interactions between the particles. For the former the
% Gans formalism is applied while a retarded variation of the Maxwell-Garnett effective medium theory (EMT)/Mie + Gans is employed for the latter (GEM model).
% 
% Usage:
% For regression: deviation = extFcn(lambda,Abs,T,r_GNP,polydisp,beta,beta_CV,eta0,etaCoeff,parA,...
%     x_SC,fillFact,r_SC,lu_bounds,fixedParFlag,plotFlag,lambdaFloor,lambdaCeil,sizeDepRealEpsFlag,dielectricFcn,parFvalSaveAddress)
% For simulation: [deviation,Abs_calc,concGNP_nM,concGNP_ppm,concSC_nM] = ... 
%     extFcn(lambda,Abs,T,r_GNP,polydisp,beta,beta_CV,eta0,etaCoeff,parA,...
%     x_SC,fillFact,r_SC,lu_bounds,fixedParFlag,plotFlag,lambdaFloor,lambdaCeil,sizeDepRealEpsFlag,dielectricFcn,parFvalSaveAddress)
% Input:
%   lambda = wavelength in vacuum (nm); it should be compatible with the bulk dielectric function of Au data (e.g., every 1 nm)
%   Abs = experimentally measured extinction (considering the small size of particles, here we use absorbance and extinction interchangably)
%   T = temperature (K)
%   r_GNP = volume-averaged equivalent spherical radius of GNPs (nm)
%   polydisp = coefficient of variation for log-normal size distribution
%   beta = mean GNP aspect ratio (prolate-shaped)
%   beta_CV = coefficient of variation for normal aspect ratio distribution
%   eta0 = free-path effect (FPE) parameter (zero's power coefficient in case of polynomial size-dependence)
%   etaCoeff = vector of coefficients for a polynomial describing the size
%   dependence of FPE (from the smallest to the largest power)
%   parA = phenomenological parameter in FPE equation
% 	x_SC = number fraction of liquid-like superclusters (SCs) out of all the scatterers, i.e., SCs + noninteracting GNPs
% 	fillFact = filling factor, i.e., volume fraction of GNPs inside SCs
% 	r_SC = average radius of spherical SCs (nm)
% 	lu_bounds = two-row matrix with lower and upper bounds for various parameters in the first and second rows, respectively; used for centering and scaling the parameters to the interval [-1,1]; should be provided only for optimization variables (not the fixed parameters)
% 	fixedParFlag = vector denoting fixed parameters (1) or those to be optimized (0)
% 	plotFlag = set 1 for plotting the output and 0 for skipping the plot
% 	lambdaFloor = lowest wavelength at which extinction is calculated (nm)
% 	lambdaCeil = highest wavelength at which extinction is calculated (nm)
% 	sizeDepRealEpsFlag = set 1 to correct both real and imaginary parts for
% 	FPE and 0 correcting only the imaginary part
% 	dielectricFcn = dielectric function of bulk gold relative to vacuum
% 	parFvalSaveAddress = directory to which function evaluations and their
% 	corresponding set of parameters are saved during optimization
% Output:
%   deviation = total sum of squares of the differences between calculated and experimental extinction values scaled to be close to unity in the case of regression and range-normalized root mean square error (NRMSE) in case of simulation
% 	Abs_calc = calculated extinction
% 	concGNP_nM = total number concentration of GNPs (in nanomolar, nM)
% 	concGNP_ppm = total mass concentration of GNPs assuming the bulk gold density 19.3 g/cm3 (ppm Au(0))
% 	concSC_nM = number concentration of SCs (nM)
%
% This function is part of the MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling"
% developed by M. Reza Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
% Please cite our article:
% M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".

%% Uncentering and unscaling the input parameters
if ~isempty(lu_bounds) % Providing bounds for a parameter means it is centered and scaled (fixedParFlag=0)
    if isempty(etaCoeff) % eta treaeted as a parameter (to be optimized for a single dataset)
        par = [r_GNP,polydisp,beta,beta_CV,eta0,x_SC,fillFact,r_SC];
    else % eta provided by the user
        par = [r_GNP,polydisp,beta,beta_CV,x_SC,fillFact,r_SC];
    end
    
    boundCounter = 1; % counter for parameters that should be unscaled and uncentered
    for iPar=1:length(par) % 8 potential model parameters: r_GNP,polydisp,beta,beta_CV,eta0,x_SC,fillFact,r_SC
        if fixedParFlag(iPar) == 0 % parameters to be optimized should be unscaled and uncentered
            par(iPar) = (par(iPar)+1).*(lu_bounds(2,boundCounter)-lu_bounds(1,boundCounter))/2 + lu_bounds(1,boundCounter);
            boundCounter = boundCounter+1;
            if iPar>=length(par)-2 % the last three parameters (EMT parameters) are also log-transformed for optimization
                par(iPar) = 10.^par(iPar);
            end
        end
    end
    % Assign the parameters to individual variables
    r_GNP = par(1);
    polydisp = par(2);
    beta = par(3);
    beta_CV = par(4);
    
    if isempty(etaCoeff) % eta being optimized
        eta0 = par(5);
        x_SC = par(6);
        fillFact = par(7);
        r_SC = par(8);
    else % eta provided (either as input fixed value or as a polynomial function of r_GNP)
        x_SC = par(5);
        fillFact = par(6);
        r_SC = par(7);
    end
end

if isempty(etaCoeff) % Fixed eta
    eta = eta0;
else % Polynomial dependence on r_GNP
    eta = eta0 + sum(etaCoeff.*r_GNP.^(1:length(etaCoeff)));
end

%% Constructing wavelength vector, angular frequency, and the corresponding experimental Abs data
Abs = [lambda,Abs];
lambdaStep = 1; % step size for wavelength (nm); change it if you want to fit with different spacing (e.g., 5 nm)
lambda = (lambdaFloor:lambdaStep:lambdaCeil)'; % Construct lambda vector for extinction calculations (nm)
cLight = 299792458; % Speed of light in vacuum (m/s)
omega = 2*pi*cLight./lambda/1e-9; % Angular frequency (rad/s)

lambdaStepIndex = (find(Abs(:,1)>=lambdaFloor+lambdaStep,1)-find(Abs(:,1)>=lambdaFloor,1)); % Index of Abs data corresponding the lambda vector
Abs = Abs(find(Abs(:,1)>=lambdaFloor,1):lambdaStepIndex:find(Abs(:,1)>=lambdaCeil,1),2);

%% Dielectric function of water (Release on the Refractive Index of Ordinary Water Substance as a Function of Wavelength, Temperature and Pressure, 1997)
rhoWater = 0.14395/0.0112^(1+(1-T/649.727)^0.05107); % Density of water from DDBST
rhoBar = rhoWater/1000;
T_bar = T/273.15;
lambdaBar = lambda/589;
epsWater = (1+2*rhoBar*...
    ( 0.244257733+9.74634476e-3*rhoBar-3.73234996e-3*T_bar+2.68678472e-4*lambdaBar.^2*T_bar+1.58920570e-3./lambdaBar.^2+2.45934259e-3./(lambdaBar.^2-0.229202^2)+0.900704920./(lambdaBar.^2-5.432937^2)-1.66626219e-2*rhoBar^2 ))./...
    (1-rhoBar*( 0.244257733+9.74634476e-3*rhoBar-3.73234996e-3*T_bar+2.68678472e-4*lambdaBar.^2*T_bar+1.58920570e-3./lambdaBar.^2+2.45934259e-3./(lambdaBar.^2-0.229202^2)+0.900704920./(lambdaBar.^2-5.432937^2)-1.66626219e-2*rhoBar^2 ));

%% Dielectric function of bulk gold
epsBulk = dlmread([dielectricFcn, '.txt']); % e.g., Yakubovsky_25nm (lambda, real(eps), imag(eps) in columns 1 to 3, respectively); by default the data must have a resolution of 1 nm or less
lambdaStepIndex = (find(epsBulk(:,1)>=lambdaFloor+lambdaStep,1)-find(epsBulk(:,1)>=lambdaFloor,1)); % Selecting the proper data points compatible with lambda and Abs data
epsBulk = epsBulk(find(epsBulk(:,1)>=lambdaFloor,1):lambdaStepIndex:find(epsBulk(:,1)>=lambdaCeil,1),2) + ...
    1i*epsBulk(find(epsBulk(:,1)>=lambdaFloor,1):lambdaStepIndex:find(epsBulk(:,1)>=lambdaCeil,1),3);

%% T-dependence of bulk plasmon frequency and damping coefficient for free electrons (see our paper for explanation)
% T-dependent bulk plasmon frequency
T_R = 298.15; % Reference temperature (K)
if dielectricFcn(1:2) == 'Ya' % If the bulk data are that of Yakubovsky_25nm
    omegaP_RT = 1.37e+16; % Room-temperature bulk plasmon frequency (rad/s)
    gammaBulk_ep0 = 7.09e+13; % Room-temperature electron-phonon damping constant (rad/s)
else % Some general purpose values (e.g., for example with Johnson and Christy's (JC) data)
    omegaP_RT = 1.32e+16; % from Amendola and Meneghetti, 2009 and Granqvist and Hunderi, 1977 (rad/s)
    gammaBulk_ep0 = 7.26e+13; % back calculated from JC's bulk damping coefficient (Etchegoin et al. 2006; rad/s)
end
alphaV = 4.17e-5; % volume thermal expansion coefficient for bulk gold (1/K)
omegaP = omegaP_RT/sqrt(1+alphaV*(T-T_R)); % bulk plasmon frequency at temperature T (rad/s)
% Electron-phonon contribution
thetaDebye = 170; % Debye temperature of Au (K)
% % Uncomment the next 7 lines for using the analytical expression by
% Dubinov and Dubinova, 2008, (4th order Debye function for energy); if you don't have symbolic toolbox use the numerical method below
% z = thetaDebye/T;
% z_R = thetaDebye/T_R;
% m = (0:4)';
% DebyeFcn_4th = 4/z^5 * ( factorial(4)*zeta(5) + real(sum((-1).^(4-m+1) * factorial(4)./factorial(m) .* z.^m .* polylog(4-m+1,exp(z)))) ) - 4/5;
% DebyeFcn_4th_RT = 4/z_R^5 * ( factorial(4)*zeta(5) + real(sum((-1).^(4-m+1) * factorial(4)./factorial(m) .* z_R.^m .* polylog(4-m+1,exp(z_R)))) ) - 4/5;
% gammaBulk_ep = gammaBulk_ep0 * ( 0.4 + DebyeFcn_4th );
% gammaBulk_ep_RT = gammaBulk_ep0 * ( 0.4 + DebyeFcn_4th_RT );
% Uncomment for numerical integration of the Debye function for energy
gammaBulk_ep = gammaBulk_ep0 * ( 0.4 + 4 * (T/thetaDebye)^5 * integral(@(z) z.^4./(exp(z)-1), 0, thetaDebye/T) ); % Bulk electron-phonon scattering at temperatre T
gammaBulk_ep_RT = gammaBulk_ep0 * ( 0.4 + 4 * (T_R/thetaDebye)^5 * integral(@(z) z.^4./(exp(z)-1), 0, thetaDebye/T_R) ); % Bulk electron-phonon scattering at room temperatre
% electron-electron contribution
kB = 8.6173303e-5; % Boltzmann constant (eV/K)
Sigma = 0.55; % Fermi-surface average of scattering probability
Delta = 0.77; % Fractional umklapp scattering
hBar = 6.582119514e-16; % Reduced Planck's constant (eV.s/rad)
E_F = 5.51; % Fermi energy (eV)
gammaBulk_ee = pi^3*Sigma*Delta*((kB*T)^2+(hBar*omega/2/pi).^2)/12/E_F/hBar; % Bulk electron-electron scattering at temperatre T
gammaBulk_ee_RT = pi^3*Sigma*Delta*((kB*T_R)^2+(hBar*omega/2/pi).^2)/12/E_F/hBar; % Bulk electron-electron scattering at room temperatre
% Adding the 2 contributions
gammaBulk = gammaBulk_ep + gammaBulk_ee;
gammaBulk_RT = gammaBulk_ep_RT + gammaBulk_ee_RT;

%% Extracting the contribution of interband transitions to the gold dielectric function
% (assumed to be Size- and T-independent)
epsIB = epsBulk - ...
    ( 1-omegaP_RT^2./(omega.^2+gammaBulk_RT.^2) + 1i*omegaP_RT^2.*gammaBulk_RT./(omega.^2+gammaBulk_RT.^2)./omega );

%% Calculating extinction cross section
% Lambda values are along the rows, i.e., the first row is the first lambda, the second row is the second lambda, etc (first dimension); discritization of beta is along the columns (second dimension); discritization of the radius is along the pages (third dimension)
if beta_CV > 0.01 % Set beta_CV=0 to use a mean aspect ratio
    beta_SD = beta_CV*beta; % standard deviation of aspect ratio distribution (normal)
    
    beta_discr = linspace(max(1,beta-3*beta_SD),beta+3*beta_SD,10); % discretized aspect ratios
    
    pd = makedist('Normal','mu',beta,'sigma',beta_SD); % normal probability distribution object
    t = truncate(pd,max(beta-3*beta_SD,1),beta+3*beta_SD); % truncate the distribution
    
    beta_ND = pdf(t,beta_discr)/sum(pdf(t,beta_discr)); % probability density function corresponding the descretized beta values
else % Dirac delta function (no distribution)
    beta_discr = beta;
    beta_ND = 1;
end

if polydisp > 0.01 % Set polydisp=0 to use a mean aspect ratio
    r_discr(1,1,:) = linspace(max(1,r_GNP/3/exp(polydisp)),min(15,r_GNP*3*exp(polydisp)),15); % lower and upper bound do not exceed 1 and 15 nm, respectively (nm)
    r_LND = exp(-(log(r_discr/r_GNP)).^2/2/polydisp^2)/sqrt(2*pi)/polydisp./r_discr ./ ...
        sum(exp(-(log(r_discr/r_GNP)).^2/2/polydisp^2)/sqrt(2*pi)/polydisp./r_discr); % Normalized to give an integral equal to 1
    fillFact_dist = fillFact * r_discr.^3 .* r_LND ./ sum(r_discr.^3.*r_LND);
else % Dirac delta function (no distribution
    r_discr = r_GNP;
    r_LND = 1;
    fillFact_dist = fillFact;
end

% Number of descritization grid points 
beta_discrNumb = size(beta_discr,2);
r_discrNumb = size(r_discr,3);
% Generate three-dimensional grid of descritization
beta_discr = repmat(beta_discr,length(lambda),1,r_discrNumb);
r_discr = repmat(r_discr,length(lambda),beta_discrNumb,1);
beta_ND = repmat(beta_ND,length(lambda),1,r_discrNumb);
r_LND = repmat(r_LND,length(lambda),beta_discrNumb,1);
fillFact_dist = repmat(fillFact_dist,length(lambda),beta_discrNumb,1);

if x_SC >= 1e-16 % Extinction by interacting spheroids in a spherical superclusters (effective medium theory, EMT, of Maxwell-Garnett corrected for retardation per Granqvist and Hunderi, 1977) + noninteracting GNPs (Gans), weighted by their number fractions
    ecc = sqrt(1-1./beta_discr.^2); % eccentricity of prolate shaped particles
    L_eff = 8*beta_discr.*r_discr*1e-9./beta_discr.^(1/3)/3./(1+beta_discr.*asin(ecc)./ecc); % effective size for FPE (4*volume/surface area; m)
    % Correction for spheres (ecc=0 -> L_eff=nan)
    sphereIndex = find(isnan(L_eff));
    if ~isempty(sphereIndex)
        L_eff(sphereIndex) = 4*r_discr(:,1,:)*1e-9/3;
    end
    vf = 1.4e6; % Fermi speed (m/s)
    gammaGNP = repmat(gammaBulk,1,beta_discrNumb,r_discrNumb) + eta*parA*vf./L_eff; % Size-corrected free electron damping frequency (rad/s)
    
    omegaRPMT = repmat(omega,1,beta_discrNumb,r_discrNumb); % Expand angular frequencies over a grid for beta and r_GNP descritazation
    
    if sizeDepRealEpsFlag % Correct dielectric function of gold for size-dependence in both real and imaginary parts
        epsGNP = repmat(epsIB,1,beta_discrNumb,r_discrNumb) + 1 - omegaP^2./(omegaRPMT.^2 + 1i*omegaRPMT.*gammaGNP); % Both real and imag parts corrected for damping
    else % Only imag part corrected for size-dependent damping
        epsGNP = repmat(epsIB,1,beta_discrNumb,r_discrNumb) + ...
        1-omegaP^2./(omegaRPMT.^2+repmat(gammaBulk,1,beta_discrNumb,r_discrNumb).^2) + ...
        1i*omegaP^2*gammaGNP./(omegaRPMT.^2+gammaGNP.^2)./omegaRPMT;
    end
    
    pFact_a = (1-ecc.^2).*(log((1+ecc)./(1-ecc))/2./ecc-1)./ecc.^2; % Longitudinal depolarization factor
    pFact_b = (1-pFact_a)/2; % Transversal depolarization factors
    
    % Correction for spheres (ecc=0 -> pFact=nan)
    sphereIndex = find(isnan(pFact_a));
    if ~isempty(sphereIndex)
        pFact_a(sphereIndex) = 1/3;
        pFact_b(sphereIndex) = 1/3;
    end
    % Expand over a grid for beta and r_GNP descritazation (necessary for older version of MATLAB!)
    epsWaterRPMT = repmat(epsWater,1,beta_discrNumb,r_discrNumb);
    lambdaRPMT = repmat(lambda,1,beta_discrNumb,r_discrNumb);
    
    % Retarded MG theory by Granqvist and Hunderi, 1977
    % Volume normalized polarizability times 4pi (Supp. Eq. 9)
    alpha_GNP = 1/3 *...
        ((epsGNP-epsWaterRPMT)./(epsWaterRPMT+pFact_a.*(epsGNP-epsWaterRPMT)) + 2*(epsGNP-epsWaterRPMT)./(epsWaterRPMT+pFact_b.*(epsGNP-epsWaterRPMT)));
    % Non-retarded effective medium dielectric function
    epsEff = epsWater .* (1+2/3*sum(sum(fillFact_dist.*beta_ND.*alpha_GNP,3),2)) ./ (1-1/3*sum(sum(fillFact_dist.*beta_ND.*alpha_GNP,3),2)); % Initial guess with phaseFact_delta = 0
    maxIter = 20;
    iter = 0;
    epsEff_dev = 1;
    while (iter<maxIter) && (epsEff_dev > 1e-3) % Correction for retardation effects
        epsEff_old = epsEff;
        phaseFact_delta = 2*r_GNP*(pi/sqrt(18)/fillFact)^(1/3) * 2*pi*sqrt(epsEff_old)./lambda;
        epsEff = epsWater .* ( (1+(1-1/3*exp(1i*phaseFact_delta)).*sum(sum(fillFact_dist.*beta_ND.*alpha_GNP,3),2))./...
            (1-1/3*exp(1i*phaseFact_delta).*sum(sum(fillFact_dist.*beta_ND.*alpha_GNP,3),2)) );
        epsEff_dev = max(abs(epsEff-epsEff_old));
        iter = iter+1;
    end
    
    % Full Mie theory for extinction cross section of the spherical
    % effective media (interacting GNPs in liquid-like superclusters)
    % Mie code taken from: Demers, Steven ME, et al. "Ultraviolet Analysis of Gold Nanorod and Nanosphere Solutions." The Journal of Physical Chemistry C 121.9 (2017): 5201-5207.
    xMAX = max(2*pi*sqrt(epsWater)*r_SC./lambda); % largest x dictating the necessary number of multipolar order
    if xMAX <= 8
        index_n_max = floor(xMAX + 4*xMAX^(1/3) + 1); % Multipolar order calculated as discussed in Quinten, 2011 textbook
    else
        index_n_max = floor(xMAX + 4.05*xMAX^(1/3) + 2);
    end
    % Vectorizing for summation over multipolar orders
    x = repmat(2*pi*sqrt(epsWater)*r_SC./lambda,1,index_n_max);
    index_n = repmat((1:index_n_max),length(lambda),1);
    m = repmat(sqrt(epsEff)./sqrt(epsWater),1,index_n_max);
    % Mie coefficients
    a1 = m.*riccatibessel(index_n,m.*x).*riccatibesselprime(index_n,x);
    a2 = riccatibessel(index_n,x).*riccatibesselprime(index_n,m.*x);
    a3 = m.*riccatibessel(index_n,m.*x).*riccatihankelprime(index_n,x);
    a4 = riccatihankel(index_n,x).*riccatibesselprime(index_n,m.*x);
    an = (a1-a2)./(a3-a4);
    b1 = riccatibessel(index_n,m.*x).*riccatibesselprime(index_n,x);
    b2 = m.*riccatibessel(index_n,x).*riccatibesselprime(index_n,m.*x);
    b3 = riccatibessel(index_n,m.*x).*riccatihankelprime(index_n,x);
    b4 = m.*riccatihankel(index_n,x).*riccatibesselprime(index_n,m.*x);
    bn = (b1-b2)./(b3-b4);
    % Extinction crsoss section (m2) of SCs from summation over multipolar orders
    sigmaExt_SC = sum( (2*index_n+1).*real(an+bn), 2 ).*lambda.^2*1e-18./2/pi./epsWater;
    
    % Contribution of independent GNPs (noninteracting or Gans)
    eps1 = real(epsGNP);
    eps2 = imag(epsGNP);
    % Extinction cross for descritized grid points (each point with a specific size and aspect ratio)
    sigmaExt_GNP = 2*pi*(4/3*pi*r_discr.^3*1e-27).*epsWaterRPMT.^1.5.*( eps2./pFact_a.^2./((eps1+epsWaterRPMT.*(1-pFact_a)./pFact_a).^2+eps2.^2) + ...
    2*eps2./pFact_b.^2./((eps1+epsWaterRPMT.*(1-pFact_b)./pFact_b).^2+eps2.^2) )/3./lambdaRPMT/1e-9;
    % Extinction cross section of noninteracting GNPs by weighted summation over PDFs
    sigmaExt_GNP = sum( sum(sigmaExt_GNP .* beta_ND .* r_LND, 3), 2 ); % Integration over normal beta distribution and log-normal PSD
    
    % Add the two contributions considering the corresponding the fraction of number concentrations of GNPs and SCs
    sigmaExt = x_SC*sigmaExt_SC + (1-x_SC)*sigmaExt_GNP;
else % Extinction by noninteracting prolate spheroids with noramlly distributed aspect ratio and log-normal distribution of equivalent spherical radius
    % Look for comments in the previous part
    ecc = sqrt(1-1./beta_discr.^2); % eccentricity
    L_eff = 8*beta_discr.*r_discr*1e-9./beta_discr.^(1/3)/3./(1+beta_discr.*asin(ecc)./ecc); % effective GNP size for FPE (m)
    sphereIndex = find(isnan(L_eff));
    if ~isempty(sphereIndex)
        L_eff(sphereIndex) = 4*r_discr(:,1,:)*1e-9/3; % Correction for ecc = 0
    end
    vf = 1.4e6; % Fermi speed (m/s)
    gammaGNP = repmat(gammaBulk,1,beta_discrNumb,r_discrNumb) + eta*parA*vf./L_eff; % Size-corrected free electron damping frequency
    
    omegaRPMT = repmat(omega,1,beta_discrNumb,r_discrNumb);
    
    if sizeDepRealEpsFlag
        epsGNP = repmat(epsIB,1,beta_discrNumb,r_discrNumb) + 1 - omegaP^2./(omegaRPMT.^2 + 1i*omegaRPMT.*gammaGNP); % Both real and imag parts corrected for damping
    else
        epsGNP = repmat(epsIB,1,beta_discrNumb,r_discrNumb) + ...
        1-omegaP^2./(omegaRPMT.^2+repmat(gammaBulk,1,beta_discrNumb,r_discrNumb).^2) + ...
        1i*omegaP^2*gammaGNP./(omegaRPMT.^2+gammaGNP.^2)./omegaRPMT; % Only imag part corrected for damping
    end
    
    pFact_a = (1-ecc.^2).*(log((1+ecc)./(1-ecc))/2./ecc-1)./ecc.^2;
    pFact_b = (1-pFact_a)/2;
    
    sphereIndex = find(isnan(pFact_a));
    if ~isempty(sphereIndex)
        pFact_a(sphereIndex) = 1/3; % Correction for ecc = 0
        pFact_b(sphereIndex) = 1/3; % Correction for ecc = 0
    end
   
    epsWaterRPMT = repmat(epsWater,1,beta_discrNumb,r_discrNumb);
    lambdaRPMT = repmat(lambda,1,beta_discrNumb,r_discrNumb);

    eps1 = real(epsGNP);
    eps2 = imag(epsGNP);
    
    sigmaExt = 2*pi*(4/3*pi*r_discr.^3*1e-27).*epsWaterRPMT.^1.5.*( eps2./pFact_a.^2./((eps1+epsWaterRPMT.*(1-pFact_a)./pFact_a).^2+eps2.^2) + ...
    2*eps2./pFact_b.^2./((eps1+epsWaterRPMT.*(1-pFact_b)./pFact_b).^2+eps2.^2) )/3./lambdaRPMT/1e-9;
    
    sigmaExt = sum( sum(sigmaExt .* beta_ND .* r_LND, 3), 2 ); % Integration over normal beta distribution and log-normal PSD
end

%% Plotting the results or calculating the objective function
i400 = find(lambda>=400,1);
i500 = find(lambda>=500,1);
iLastLambda = find(lambda>=800,1); % Beyond 800 nm the Abs data are literally pure noise
if isempty(iLastLambda) % If data are not down to 800 nm just take the last data
    iLastLambda = length(lambda);
end
% Experimental SPR
[~,iSpr] = max(Abs(i500:end));
iSpr = iSpr+i500-1;
% Calculated SPR
[~,iSpr_calc] = max(sigmaExt(i500:end));
iSpr_calc = iSpr_calc+i500-1;
iSpr_calc(iSpr_calc==1)=2; % To prevent errors during optimization (if the calculated max is at the lowest lambda)
iSpr_calc(iSpr_calc==iLastLambda)=iLastLambda-1; % To prevent errors during optimization (if the calculated max is at the lowest lambda)
% Total number concentration of the scatterers (nM)
concGNPandSC_nM = log(10)*1e8*mean(Abs(iSpr-1:iSpr+1)./sigmaExt(iSpr_calc-1:iSpr_calc+1))/6.022e23;

if plotFlag
    concSC_nM = concGNPandSC_nM*x_SC; % SC number concentration (nM)
    concGNP_nM = concGNPandSC_nM*(1-x_SC) + concSC_nM*fillFact*r_SC^3/sum(r_LND(1,1,:).*r_discr(1,1,:).^3); % GNP number concentration (nM)
    concGNP_ppm = concGNP_nM*6.022e23*19.3*(4/3)*pi*sum(r_LND(1,1,:).*r_discr(1,1,:).^3)*1e-27; %  GNP mass concentration (ppm) assuming bulk density of gold (0.01 m optical path length)
    
    Abs_calc = sigmaExt*6.022e23*concGNPandSC_nM/log(10)/1e8; % Calculated extinction
    % Range-normalized RMSE
    deviation = sqrt(sum((Abs_calc(i400:iLastLambda)-Abs(i400:iLastLambda)).^2)...
        /length(Abs(i400:iLastLambda)))/(max(Abs(i400:iLastLambda))-min(Abs(i400:iLastLambda)));
    
%     figure('Color','white')
    plot(lambda,Abs,'ro'); hold on;
    plot(lambda,Abs_calc,'k--','LineWidth',1.5); hold off;
    xlabel('\lambda (nm)','FontSize',16,'FontWeight','bold');
    ylabel('Extinction (a.u.)','FontSize',16,'FontWeight','bold');
    axis square
    ax = gca;
    set(ax,'FontSize',16,'FontWeight','bold');
else
    if (x_SC >= 1e-12) && (3*fillFact/4/pi/r_GNP^3 <= ... % Local concentration of GNPs inside SCs less than or equal to the average GNP concentration in the reaction medium
            (1-x_SC)*concGNPandSC_nM*6.022e-10 + x_SC*concGNPandSC_nM*6.022e-10*fillFact*(r_SC/r_GNP)^3)
        deviation = Inf;
        disp('Local concentration of GNPs inside SCs <= average GNP concentration in the reaction medium!')
        disp([r_GNP,beta,x_SC,fillFact,r_SC])
    elseif (x_SC >= 1e-12) && ((4/3)*pi*6.022e-10*concGNPandSC_nM*(x_SC*r_SC^3+(1-x_SC)*r_GNP^3) > pi/sqrt(18))
        deviation = Inf;
        disp('Total volume fraction of scatterers > 74%!')
        disp(concGNPandSC_nM)
        disp([r_GNP,beta,x_SC,fillFact,r_SC])
    elseif (x_SC >= 1e-12) && ... % percGNPinSC > 100%
            (100*x_SC*fillFact*(r_SC/r_GNP)^3/((1-x_SC)+x_SC*fillFact*(r_SC/r_GNP)^3)>100)
        deviation = Inf;
        disp('percGNPinSC > 100%!')
        disp(concGNPandSC_nM)
        disp([r_GNP,beta,x_SC,fillFact,r_SC])
    else
        Abs_calc = sigmaExt*6.022e23*concGNPandSC_nM/log(10)/1e8;
        deviation = 1e+2*sum( (Abs_calc-Abs).^2 ); % Scaled to be in the order of unity close to the optimal point
    end
    % During optimization we don't need these concentrations!
    concSC_nM = [];
    concGNP_nM = [];
    concGNP_ppm = [];
    % Saving fvals (deviation) and the corresponding parameters for the
    % estimation of 95% confidence bounds according to Schwaab et al. 2008
    if ~isempty(parFvalSaveAddress) % Providing a directory means we want to save the data
        if isempty(etaCoeff) % eta optimized
            dlmwrite(parFvalSaveAddress,[r_GNP,beta,x_SC,fillFact,r_SC,concGNPandSC_nM,eta0,deviation],'-append','delimiter','\t')
        else % eta not optimized
            dlmwrite(parFvalSaveAddress,[r_GNP,beta,x_SC,fillFact,r_SC,concGNPandSC_nM,deviation],'-append','delimiter','\t')
        end
    end
end
