function rb = riccatibessel(n,x)

rb = x.*spbesselj(n,x);