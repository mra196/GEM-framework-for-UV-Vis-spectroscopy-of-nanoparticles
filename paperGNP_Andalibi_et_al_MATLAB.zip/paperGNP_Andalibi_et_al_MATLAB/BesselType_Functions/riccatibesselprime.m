function rbp = riccatibesselprime(n,x)

rbp = (n+1).*spbesselj(n,x)-x.*spbesselj(n+1,x); 