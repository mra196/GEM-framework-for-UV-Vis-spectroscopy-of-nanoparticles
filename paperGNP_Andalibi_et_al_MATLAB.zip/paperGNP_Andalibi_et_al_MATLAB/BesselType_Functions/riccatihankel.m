function rh = riccatihankel(n,x)

rh = x.*sphankelh(n,x); 