function rhp = riccatihankelprime(n,x)

rhp = (n+1).*sphankelh(n,x)-x.*sphankelh(n+1,x);