% This script is for the regression of extinction spectra in seed and grown
% GNP suspensions and calibration of the FPE parameter eta fixing the radii
% to those estimated from TEM.
%
% This script is part of the MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling"
% developed by M. Reza Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
% Please cite our article:
% M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".
% 
% % Add path to all necessary folders
% addpath(genpath('...\paperGNP_Andalibi_et_al_MATLAB'));
% % Set the directory
% cd '...\paperGNP_Andalibi_et_al_MATLAB'
% % Load treated spectra
% load('...\input_output\EXP_15-85_70''C\TreatedSpectra.mat')
%
% Set up for saving fval and corresponding parameters for 95% confidence bound calculation
myCluster = parcluster('local');
workerNumber = myCluster.NumWorkers; % The number of CPU workers (saving fvals and parameters in separate text files each for one worker)
parFvalSaveAddress = input('Address for saving parFval file: ','s'); % Directory to save the text file (e.g., ...\paperGNP_Andalibi_et_al_MATLAB\input_output\EXP_15-85_70'C\)

%% Read seed and grown particle radii (volume-averaged values from TEM)
r_GNP_seed = input('Seed radius (nm): ');
r_GNP_grown = input('Grown GNP radius (nm): ');

%% Set optimization tolerances and fixed input
epsBulkData = 'Yakubovsky_25nm'; % Name of the text file containing the bulk dielectric function of Au
epsFlag = 1; % Correct for FPE effect in both real and imag parts of dielectric function
parA = 4/3; % So that it reduces to 1 for spheres (considering Leff = 4/3 * r)
lambdaFloorPlot = 200; % lower bound of wavelength for the simulated extinction
lambdaCeilPlot = 800; % upper bound of wavelength for the simulated extinction
lambdaFloorFit_noninteract = 400; % lower bound of wavelength for the fitting with Gans model
lambdaCeilFit_noninteract = 800; % upper bound of wavelength for the fitting with Gans model
lambdaFloorFit_GEM = 400; % lower bound of wavelength for the fitting with GEM model
lambdaCeilFit_GEM = 800; % upper bound of wavelength for the fitting with GEM model
lambdaStep = 1; % step size of wavelength
% Ratio below which fval is within 95% confidence neighborhood of the optimal point (Schwaab et al. 2008 (Eq. 16))
confBound_noninteract = 1 + 2/((lambdaCeilFit_noninteract-lambdaFloorFit_noninteract+lambdaStep)/lambdaStep-2) *...
    finv(0.95,2,(lambdaCeilFit_noninteract-lambdaFloorFit_noninteract+lambdaStep)/lambdaStep-2);
confBound_GEM = 1 + 5/((lambdaCeilFit_GEM-lambdaFloorFit_GEM+lambdaStep)/lambdaStep-5) *...
    finv(0.95,5,(lambdaCeilFit_GEM-lambdaFloorFit_GEM+lambdaStep)/lambdaStep-5);
% Optimization tolerances
TolFun = 1e-3;
TolX = 1e-3;

%% Initializing regression parameters and output
numbTimeSteps = size(Abs,2); % total number of spectra to be fitted

% Model parameters
% Gans model
r_GNP_noninteract = zeros(numbTimeSteps,1); % mean particle radius
% polydisp_noninteract = zeros(numbTimeSteps,1); % Uncomment if you want to fit!
beta_noninteract = zeros(numbTimeSteps,1); % mean particle aspect ratio
% beta_CV_noninteract = zeros(numbTimeSteps,1); % Uncomment if you want to fit!
% eta_noninteract = zeros(numbTimeSteps,1); % Uncomment if you want to fit!

% GEM model
r_GNP_GEM = zeros(numbTimeSteps,1);
% polydisp_GEM = zeros(numbTimeSteps,1); % Uncomment if you want to fit!
beta_GEM = zeros(numbTimeSteps,1);
% beta_CV_GEM = zeros(numbTimeSteps,1); % Uncomment if you want to fit!
% eta_GEM = zeros(numbTimeSteps,1); % Uncomment if you want to fit!
x_SC = zeros(numbTimeSteps,1); % number fraction of SCs out of all the scatterers
fillFact = zeros(numbTimeSteps,1); % filling factor (volume fraction) of GNPs inside SCs
r_SC = zeros(numbTimeSteps,1); % mean radius of liquid-like supercluster (SC)

% Outputs
exitflag_noninteract = 1000*ones(numbTimeSteps,1); % refer to "minimize" documentation
fval_noninteract = 1000*ones(numbTimeSteps,1); % objective function (chi-squared) value for Gans fits
exitflag_GEM = 1000*ones(numbTimeSteps,1);
fval_GEM = 1000*ones(numbTimeSteps,1); % objective function (chi-squared) value for GEM fits
Abs_calc_noninteract = zeros((lambdaCeilPlot-lambdaFloorPlot)/lambdaStep+1,numbTimeSteps); % calculated optimized extinction using the Gans model
Abs_calc_GEM = zeros((lambdaCeilPlot-lambdaFloorPlot)/lambdaStep+1,numbTimeSteps); % calculated optimized extinction using the GEM model
deviation_noninteract = zeros(numbTimeSteps,1); % range-normalized RMSE for Gans model
deviation_GEM = zeros(numbTimeSteps,1); % range-normalized RMSE for GEM model
concGNP_nM_noninteract = zeros(numbTimeSteps,1);
concGNP_ppm_noninteract = zeros(numbTimeSteps,1);
concGNP_nM_GEM = zeros(numbTimeSteps,1);
concGNP_ppm_GEM = zeros(numbTimeSteps,1);
concSC_nM = zeros(numbTimeSteps,1);
GNPperSC = zeros(numbTimeSteps,1); % mean number of GNPs inside each SC
d_CC = zeros(numbTimeSteps,1); % mean center-to-center distance between GNPs inside SCs
percGNPinSC = zeros(numbTimeSteps,1); % percentage of GNPs interacting electromagnetically (inside SCs)

% Confidence intervals
% 95% CI on r_GNP, beta, C_GNP_nM, C_GNP_ppm, in columns 1 to 4 respectively
ciPos_noninteract = nan(numbTimeSteps,4);
ciNeg_noninteract = nan(numbTimeSteps,4);
% 95% CI on r_GNP, beta, x_SC, fillFact, r_SC, C_GNP_nM, C_GNP_ppm, concSC_nM, GNPperSC, percGNPinSC, d_CC, d_CC/r_GNP in columns 1 to 12 respectively
ciPos_GEM = nan(numbTimeSteps,12);
ciNeg_GEM = nan(numbTimeSteps,12);

%% Bounds for various parameters
lb_r_GNP = 2; ub_r_GNP = 15; % nm
% lb_polydisp = 0.01; ub_polydisp = 0.5;
lb_beta = 1; ub_beta = 3;
% lb_beta_CV = 0.01; ub_beta_CV = 0.5;
lb_eta = 0.2; ub_eta = 4;
lb_x_SC = log10(1e-8); ub_x_SC = log10(1);
lb_fillFact = log10(1e-3); ub_fillFact = log10(0.4);
lb_r_SC = 25; ub_r_SC = 250; % nm

searchDomainFlag_GEM = nan(numbTimeSteps,5); % matrix storing the search domain for every fit (0 and 1 for broad and narrow search spaces, respectively)

clc

%% Calibrating eta for seeds
rng default % For reproducibility
parFval = []; % Initilize for the subsequent reading from different text files (one for each CPU worker)
parFvalFileName = [ repmat([parFvalSaveAddress,'parFval'],workerNumber,1),...
    num2str((1:workerNumber)'), repmat('.txt',workerNumber,1) ]; % each worker gets a unique filename
% create new text files or delete the file content from the previous runs
for ii=1:workerNumber
    fid = fopen(parFvalFileName(ii,:),'w'); % Open or create new file for writing. Discard existing contents, if any.
    fclose(fid);
end

r_GNP_noninteract(1) = r_GNP_seed;

% Initialize population of random starting points for optimization
popSize = 30;
lb = [lb_beta,lb_eta];
ub = [ub_beta,ub_eta];
x0 = repmat(lb,popSize,1) + rand(popSize,length(lb)).*repmat(ub-lb,popSize,1);

% Optimization problem
fval_temp = 1000*ones(popSize,1); % initialize fvals
exitflag_temp = 1000*ones(popSize,1); % initialize exitflags
x = zeros(popSize,length(lb)); % optimized points (starting from different initial guesses)
options = optimset('AlwaysHonorConstraints','bounds','TolFun',TolFun,'TolX',TolX);

tic % to track time passed
parfor ii=1:popSize
    t = getCurrentTask(); % which worker is running this optimization
    % Objective function
    objFcn = @(x) extFcn(lambda,Abs(:,1),T,r_GNP_noninteract(1),0,x(1),0,x(2),[],parA,...
        0,0,0,[],[],0,lambdaFloorFit_noninteract,lambdaCeilFit_noninteract,epsFlag,epsBulkData,parFvalFileName(t.ID,:));
    % Optimization
    [x(ii,:),fval_temp(ii),exitflag_temp(ii)] = minimize(objFcn,x0(ii,:),[],[],[],[],...
        lb,ub,[],options);
end
toc

% Check the optimization results
figure('Color','white')
subplot(1,2,1)
plot(x(:,1),fval_temp,'go')
xlabel('\beta_{seeds}')
ylabel('fval')
axis square
subplot(1,2,2)
plot(x(:,2),fval_temp,'go')
xlabel('\eta_{seeds}')
ylabel('fval')
axis square

% Extract the optimal values
[fval_noninteract(1),min_fval_index] = min(fval_temp); % choose the global optimum
exitflag_noninteract(1) = exitflag_temp(min_fval_index);
x = x(min_fval_index,:);
% Assign to the matrices
beta_noninteract(1) = x(1);
eta_seeds = x(2);

% Check how the calculated spectrum looks for the seeds
figure('Color','white')
[deviation_noninteract(1), Abs_calc_noninteract(:,1), concGNP_nM_noninteract(1), concGNP_ppm_noninteract(1), ~] = ... 
    extFcn(lambda,Abs(:,1),T,r_GNP_noninteract(1),0,beta_noninteract(1),0,eta_seeds,[],parA,...
    0,0,0,[],[],1,lambdaFloorPlot,lambdaCeilPlot,epsFlag,epsBulkData,[]);
xlim([300,800])

% Extract points within the 95% confidence region
for ii=1:workerNumber % Combine parFval data
    parFval = [parFval;dlmread(parFvalFileName(ii,:))];
end
% fval within confidence region
iKeep = find(parFval(:,end)/fval_noninteract(1)<=confBound_noninteract);
parFval = parFval(iKeep,:);
% 95% CIs
ciPos_noninteract(1,2) = max(parFval(:,2))-beta_noninteract(1);
ciNeg_noninteract(1,2) = beta_noninteract(1)-min(parFval(:,2));

ciPos_noninteract(1,3) = max(parFval(:,6))-concGNP_nM_noninteract(1);
ciNeg_noninteract(1,3) = concGNP_nM_noninteract(1)-min(parFval(:,6));

ciPos_noninteract(1,4) = max(parFval(:,6).*6.022e23*19.3*(4/3)*pi.*parFval(:,1).^3*1e-27)-concGNP_ppm_noninteract(1);  % 0.01 m path length
ciNeg_noninteract(1,4) = concGNP_ppm_noninteract(1)-min(parFval(:,6).*6.022e23*19.3*(4/3)*pi.*parFval(:,1).^3*1e-27);

ciPos_eta_seeds = max(parFval(:,7))-eta_seeds;
ciNeg_eta_seeds = eta_seeds-min(parFval(:,7));

% Check the likelihood confidence region results
figure('Color','white')
subplot(2,3,1)
plot(parFval(:,2),parFval(:,end),'go'); hold on
plot(beta_noninteract(1),fval_noninteract(1),'ko','MarkerFaceColor','w'); hold off
xlabel('$\bar{\beta}_{seeds}$','Interpreter','Latex')
ylabel('fval')
axis square
subplot(2,3,2)
plot(parFval(:,end-1),parFval(:,end),'go'); hold on
plot(eta_seeds,fval_noninteract(1),'ko','MarkerFaceColor','w'); hold off
xlabel('$\eta_{seeds}$','Interpreter','Latex')
ylabel('fval','Interpreter','Latex')
axis square
subplot(2,3,3)
plot(parFval(:,6),parFval(:,end),'go'); hold on
plot(concGNP_nM_noninteract(1),fval_noninteract(1),'ko','MarkerFaceColor','w'); hold off
xlabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
ylabel('fval','Interpreter','Latex')
axis square
subplot(2,3,4)
plot(parFval(:,2),parFval(:,end-1),'go'); hold on
plot(beta_noninteract(1),eta_seeds,'ko','MarkerFaceColor','w'); hold off
xlabel('$\bar{\beta}_{seeds}$','Interpreter','Latex')
ylabel('$\eta_{seeds}$','Interpreter','Latex')
axis square
subplot(2,3,5)
plot(parFval(:,2),parFval(:,6),'go'); hold on
plot(beta_noninteract(1),concGNP_nM_noninteract(1),'ko','MarkerFaceColor','w'); hold off
xlabel('$\bar{\beta}_{seeds}$','Interpreter','Latex')
ylabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
axis square
subplot(2,3,6)
plot(parFval(:,end-1),parFval(:,6),'go'); hold on
plot(eta_seeds,concGNP_nM_noninteract(1),'ko','MarkerFaceColor','w'); hold off
xlabel('$\eta_{seeds}$','Interpreter','Latex')
ylabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
axis square

%% Calibrating eta for grown paraticles
parFval = []; % Initilize for the subsequent reading from different text files (one for each CPU worker)
parFvalFileName = [ repmat([parFvalSaveAddress,'parFval'],workerNumber,1),...
    num2str((1:workerNumber)'), repmat('.txt',workerNumber,1) ]; % each worker gets a unique filename
% create new text files or delete the file content from the previous runs
for ii=1:workerNumber
    fid = fopen(parFvalFileName(ii,:),'w');
    fclose(fid);
end

r_GNP_noninteract(end) = r_GNP_grown;

% Initialize population of random starting points for optimization for optimization
popSize = 30;
lb = [lb_beta,lb_eta];
ub = [ub_beta,ub_eta];
x0 = repmat(lb,popSize,1) + rand(popSize,length(lb)).*repmat(ub-lb,popSize,1);

% Optimization problem
fval_temp = 1000*ones(popSize,1); % initialize fvals
exitflag_temp = 1000*ones(popSize,1); % initialize exitflags
x = zeros(popSize,length(lb));
options = optimset('AlwaysHonorConstraints','bounds','TolFun',TolFun,'TolX',TolX);

tic % to track time passed
parfor ii=1:popSize
    t = getCurrentTask(); % which worker is running this optimization
    % Objective function
    objFcn = @(x) extFcn(lambda,Abs(:,end),T,r_GNP_noninteract(end),0,x(1),0,x(2),[],parA,...
        0,0,0,[],[],0,lambdaFloorFit_noninteract,lambdaCeilFit_noninteract,epsFlag,epsBulkData,parFvalFileName(t.ID,:));
    
    [x(ii,:),fval_temp(ii),exitflag_temp(ii)] = minimize(objFcn,x0(ii,:),[],[],[],[],...
        lb,ub,[],options);
end
toc

% Check the optimization results
figure('Color','white')
subplot(1,2,1)
plot(x(:,1),fval_temp,'go')
xlabel('\beta_{grown}')
ylabel('fval','Interpreter','Latex')
axis square
subplot(1,2,2)
plot(x(:,2),fval_temp,'go')
xlabel('\eta_{grown}')
ylabel('fval','Interpreter','Latex')
axis square

% Extract the optimal values
[fval_noninteract(end),min_fval_index] = min(fval_temp); % choose the global optimum
exitflag_noninteract(end) = exitflag_temp(min_fval_index);
x = x(min_fval_index,:);
% Assign to the matrices
beta_noninteract(end) = x(1);
eta_grown = x(2);

% Check how the calculated spectrum looks for the grown GNP
figure('Color','white')
[deviation_noninteract(end), Abs_calc_noninteract(:,end), concGNP_nM_noninteract(end), concGNP_ppm_noninteract(end), ~] = ... 
    extFcn(lambda,Abs(:,end),T,r_GNP_noninteract(end),0,beta_noninteract(end),0,eta_grown,[],parA,...
    0,0,0,[],[],1,lambdaFloorPlot,lambdaCeilPlot,epsFlag,epsBulkData,[]);
xlim([300,800])

% Extract points within the 95% confidence region
for ii=1:workerNumber % Combine parFval data
    parFval = [parFval;dlmread(parFvalFileName(ii,:))];
end
% fval within confidence region
iKeep = find(parFval(:,end)/fval_noninteract(end)<=confBound_noninteract);
parFval = parFval(iKeep,:);
% 95% CIs
ciPos_noninteract(end,2) = max(parFval(:,2))-beta_noninteract(end);
ciNeg_noninteract(end,2) = beta_noninteract(end)-min(parFval(:,2));

ciPos_noninteract(end,3) = max(parFval(:,6))-concGNP_nM_noninteract(end);
ciNeg_noninteract(end,3) = concGNP_nM_noninteract(end)-min(parFval(:,6));

ciPos_noninteract(end,4) = max(parFval(:,6).*6.022e23*19.3*(4/3)*pi.*parFval(:,1).^3*1e-27)-concGNP_ppm_noninteract(end);  % 0.01 m path length
ciNeg_noninteract(end,4) = concGNP_ppm_noninteract(end)-min(parFval(:,6).*6.022e23*19.3*(4/3)*pi.*parFval(:,1).^3*1e-27);

ciPos_eta_grown = max(parFval(:,7))-eta_grown;
ciNeg_eta_grown = eta_grown-min(parFval(:,7));

% Check the likelihood confidence region results
figure('Color','white')
subplot(2,3,1)
plot(parFval(:,2),parFval(:,end),'go'); hold on
plot(beta_noninteract(end),fval_noninteract(end),'ko','MarkerFaceColor','w'); hold off
xlabel('$\bar{\beta}_{grown}$','Interpreter','Latex')
ylabel('fval')
axis square
subplot(2,3,2)
plot(parFval(:,end-1),parFval(:,end),'go'); hold on
plot(eta_grown,fval_noninteract(end),'ko','MarkerFaceColor','w'); hold off
xlabel('$\eta_{grown}$','Interpreter','Latex')
ylabel('fval','Interpreter','Latex')
axis square
subplot(2,3,3)
plot(parFval(:,6),parFval(:,end),'go'); hold on
plot(concGNP_nM_noninteract(end),fval_noninteract(end),'ko','MarkerFaceColor','w'); hold off
xlabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
ylabel('fval','Interpreter','Latex')
axis square
subplot(2,3,4)
plot(parFval(:,2),parFval(:,end-1),'go'); hold on
plot(beta_noninteract(end),eta_grown,'ko','MarkerFaceColor','w'); hold off
xlabel('$\bar{\beta}_{grown}$','Interpreter','Latex')
ylabel('$\eta_{grown}$','Interpreter','Latex')
axis square
subplot(2,3,5)
plot(parFval(:,2),parFval(:,6),'go'); hold on
plot(beta_noninteract(end),concGNP_nM_noninteract(end),'ko','MarkerFaceColor','w'); hold off
xlabel('$\bar{\beta}_{grown}$','Interpreter','Latex')
ylabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
axis square
subplot(2,3,6)
plot(parFval(:,end-1),parFval(:,6),'go'); hold on
plot(eta_grown,concGNP_nM_noninteract(end),'ko','MarkerFaceColor','w'); hold off
xlabel('$\eta_{grown}$','Interpreter','Latex')
ylabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
axis square

%% Linear relation for eta
eta1 = (eta_grown-eta_seeds)/(r_GNP_noninteract(end)-r_GNP_noninteract(1));
eta0 = eta_grown - r_GNP_noninteract(end)*eta1;

%% Delete unncessary variables
clear ans exitflag_temp fid fval_temp ii jj iKeep lb ub myCluster min_fval_index parFval popSize r_GNP_grown r_GNP_seed ub x x0 parFvalFileName workerNumber parFvalSaveAddress 
