% This script is for the regression of extinction spectra (except for that of seeds and grown GNPS) using the GEM model (Gans formalism + retarded EMT/Mie)
%
% This script is part of the MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling"
% developed by M. Reza Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
% Please cite our article:
% M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".
% 
% % Add path to all necessary folders
% addpath(genpath('...\paperGNP_Andalibi_et_al_MATLAB'));
% % Set the directory
% cd '...\paperGNP_Andalibi_et_al_MATLAB'
% % Load the file that contains regressions of the seeds and grown GNP spectra
% load('...\input_output\EXP_15-85_70''C\fit_noninteract.mat')
%
% Set up for saving fval and corresponding parameters for 95% confidence bound calculation
myCluster = parcluster('local');
workerNumber = myCluster.NumWorkers; % The number of CPU workers (saving fvals and parameters in separate text files each for one worker)
parFvalSaveAddress = input('Address for saving parFval file: ','s'); % Directory to save the text file (e.g., ...\paperGNP_Andalibi_et_al_MATLAB\input_output\EXP_15-85_70'C\); comment this line if the address is fine
% Spectra to be fitted
index_fit = input('Index of the spectra to be fitted: '); % The index in the time vector, e.g., (2:149) or 35
if length(index_fit)>1 || index_fit ~= 2 % 2nd spectrum is treated specially because the first one has no interaction effects for sure!
    searchDomainFlag = input('Insert a vector with zeros for wide search domain and ones for narrowed search domain: ');
end
% Which parameters should be regressed
fixedParFlag = [0,1,0,1,0,0,0];

% Permissible range of GNPperSC
minGNPperSC = 1000;
maxGNPperSC = []; % leave empty if there's no upper bound

% % Uncomment if you want to change any of the following parameters (or anything else)
% lb_x_SC = log10(1e-8);
% ub_x_SC = log10(1);
% lb_fillFact = log10(1e-3);
% ub_fillFact = log10(0.4);
% lb_r_SC = 25;
% ub_r_SC = 250;
% epsBulkData = 'JC';

% Bounds for a wide search space
lb_wideSearch = [lb_r_GNP,lb_beta,lb_x_SC,lb_fillFact,lb_r_SC];
ub_wideSearch = [ub_r_GNP,ub_beta,ub_x_SC,ub_fillFact,ub_r_SC];

%% Fitting with GEM model
for jj=index_fit
    parFval = [];
    parFvalFileName = [ repmat([parFvalSaveAddress,'parFval'],workerNumber,1),...
        num2str((1:workerNumber)'), repmat('.txt',workerNumber,1) ]; % each worker gets a unique filename
    for ii=1:workerNumber
        fid = fopen(parFvalFileName(ii,:),'w');
        fclose(fid);
    end
    
    if jj == 2 % No prior GEM output for this spectrum; use global optimization over the full range for EMT parameters
        boundExpFact = 0.5; % What neighborhood around the parameters (0.5 mean 50% around the previous step)
        lb = [max((1-boundExpFact)*r_GNP_noninteract(jj-1),lb_r_GNP),...
            max((1-boundExpFact)*beta_noninteract(jj-1),lb_beta),...
            lb_x_SC,lb_fillFact,lb_r_SC];
        ub = [min((1+boundExpFact)*r_GNP_noninteract(jj-1),ub_r_GNP),...
            min((1+boundExpFact)*beta_noninteract(jj-1),ub_beta),...
            ub_x_SC,ub_fillFact,ub_r_SC];
        
        % Initialize population of random starting points
        popSize = 15;
        x0 = popGen(popSize,lb,ub,minGNPperSC,maxGNPperSC);
        
        % Log transform r_SC and its bounds for optimization
        x0(:,end) = log10(x0(:,end));
        lb(end) = log10(lb(end));
        ub(end) = log10(ub(end));
        
        % Nonlinear constraint between r_GNP, fillFact, and r_SC
        nlcon = @(x) nonlcon_parEMT(x,[],lb,ub,minGNPperSC,maxGNPperSC);

        % Optimize problem
        fval_temp = 1000*ones(popSize,1);
        exitflag_temp = 1000*ones(popSize,1);
        x = zeros(popSize,length(lb));
        options = optimset('AlwaysHonorConstraints','bounds','MaxFunEvals',1e6,'TolFun',TolFun,'TolX',TolX);
        tic
        parfor ii=1:popSize
            t = getCurrentTask();
            % Objective function
            objFcn = @(x) extFcn(lambda,Abs(:,jj),T,x(1),0,x(2),0,eta0,eta1,parA,...
                x(3),x(4),x(5),[lb;ub],fixedParFlag,0,lambdaFloorFit_GEM,lambdaCeilFit_GEM,epsFlag,epsBulkData,parFvalFileName(t.ID,:));

            [x(ii,:),fval_temp(ii),exitflag_temp(ii)] = minimize(objFcn,2*(x0(ii,:)-lb)./(ub-lb)-1,[],[],[],[],...
                -ones(1,length(lb)),ones(1,length(lb)),nlcon,options);
        end
        toc
        
        % Uncenter, unscale, and take antilog
        x = [(x(:,1:2)+1).*(ub(1:2)-lb(1:2))/2 + lb(1:2),...
            10.^((x(:,end-2:end)+1).*(ub(end-2:end)-lb(end-2:end))/2 + lb(end-2:end))];

        if length(index_fit)==1 % Check the fits one by one
            % Check the optimization results
            subplot = @(m,n,p) subtightplot (m, n, p, [0.1 0.01], [0.1 0.015], [0.1 0.1]);
            figure('Color','white')
            
            ax = subplot(2,3,1);
            plot(x(:,1),fval_temp,'ro')
            xlabel('r_{GNP}','FontSize',18,'FontWeight','bold')
            ylabel('fval','FontSize',18,'FontWeight','bold')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            set(ax,'FontSize',18,'FontWeight','bold');
            title(ax,'(a)','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
            
            ax = subplot(2,3,2);
            plot(x(:,2),fval_temp,'ro')
            xlabel('\beta','FontSize',18,'FontWeight','bold')
            ylabel('fval','FontSize',18,'FontWeight','bold')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            set(ax,'FontSize',18,'FontWeight','bold');
            title(ax,'(b)','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
            
            ax = subplot(2,3,3);
            plot(x(:,3),fval_temp,'ro')
            xlabel('x_{SC}','FontSize',18,'FontWeight','bold')
            ylabel('fval','FontSize',18,'FontWeight','bold')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            set(ax,'FontSize',18,'FontWeight','bold');
            title(ax,'(c)','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
            
            ax = subplot(2,3,4);
            plot(x(:,4),fval_temp,'ro')
            xlabel('filling factor','FontSize',18,'FontWeight','bold')
            ylabel('fval','FontSize',18,'FontWeight','bold')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            set(ax,'FontSize',18,'FontWeight','bold');
            title(ax,'(d)','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
            
            ax = subplot(2,3,5);
            plot(x(:,5),fval_temp,'ro')
            xlabel('r_{SC}','FontSize',18,'FontWeight','bold')
            ylabel('fval','FontSize',18,'FontWeight','bold')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            set(ax,'FontSize',18,'FontWeight','bold');
            title(ax,'(e)','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        end
        
        % Extract the optimal values
        [fval_GEM(jj),min_fval_index] = min(fval_temp);
        exitflag_GEM(jj) = exitflag_temp(min_fval_index);
        x = x(min_fval_index,:);
        
        r_GNP_GEM(jj) = x(1);
        beta_GEM(jj) = x(2);
        x_SC(jj) = x(3);
        fillFact(jj) = x(4);
        r_SC(jj) = x(5);
        
        % Check how the calculated spectrum looks
        if length(index_fit)==1 % Check the fits one by one
            ax = subplot(2,3,6);
        end
        [deviation_GEM(jj), Abs_calc_GEM(:,jj), concGNP_nM_GEM(jj), concGNP_ppm_GEM(jj), concSC_nM(jj)] = ...
            extFcn(lambda,Abs(:,jj),T,r_GNP_GEM(jj),0,beta_GEM(jj),0,eta0,eta1,parA,...
            x_SC(jj),fillFact(jj),r_SC(jj),[],[],1,lambdaFloorPlot,lambdaCeilPlot,epsFlag,epsBulkData,[]);
        if length(index_fit)==1 % Check the fits one by one
            xlim([300,800])
            set(ax,'FontSize',18,'FontWeight','bold');
            title(ax,'(f)','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        end
        
        % Calculate ancillary GNP-interaction output
        GNPperSC(jj) = fillFact(jj)*(r_SC(jj)/r_GNP_GEM(jj))^3;
        d_CC(jj) = 2*r_GNP_GEM(jj)*(pi/sqrt(18)/fillFact(jj))^(1/3);
        percGNPinSC(jj) = 100*concSC_nM(jj).*GNPperSC(jj)/concGNP_nM_GEM(jj);
        
    else % Possiblity of using global optimization around the output of the previous GEM fit
        searchDomainFlag_GEM(jj,:) = searchDomainFlag;
        boundExpFact = [0.1,0.1,0.5,0.2,0.2]; % for x_SC the neighborhood is log10(x_SC(jj-1))+/-0.5; for the rest its within a percentage of the previous value
        lb = zeros(1,length(boundExpFact));
        ub = zeros(1,length(boundExpFact));
        for parCounter=1:length(lb)
            if searchDomainFlag_GEM(jj,parCounter)==0
                lb(parCounter) = lb_wideSearch(parCounter);
                ub(parCounter) = ub_wideSearch(parCounter);
            else
                if parCounter==1
                    lb(parCounter) = max((1-boundExpFact(parCounter))*r_GNP_GEM(jj-1),lb_wideSearch(parCounter));
                    ub(parCounter) = min((1+boundExpFact(parCounter))*r_GNP_GEM(jj-1),ub_wideSearch(parCounter));
                elseif parCounter==2
                    lb(parCounter) = max((1-boundExpFact(parCounter))*beta_GEM(jj-1),lb_wideSearch(parCounter));
                    ub(parCounter) = min((1+boundExpFact(parCounter))*beta_GEM(jj-1),ub_wideSearch(parCounter));
                elseif parCounter==3
                    lb(parCounter) = log10(x_SC(jj-1))-boundExpFact(parCounter);
                    ub(parCounter) = min(log10(x_SC(jj-1))+boundExpFact(parCounter),log10(1));
                elseif parCounter==4
                    lb(parCounter) = log10((1-boundExpFact(parCounter))*fillFact(jj-1));
                    ub(parCounter) = min(log10((1+boundExpFact(parCounter))*fillFact(jj-1)),ub_fillFact);
                else
                    lb(parCounter) = max((1-boundExpFact(parCounter))*r_SC(jj-1),lb_r_SC);
                    ub(parCounter) = min((1+boundExpFact(parCounter))*r_SC(jj-1),ub_r_SC);
                end
            end
        end
        
        % Initialize population of random starting points
        popSize = max(5*sum(searchDomainFlag_GEM(jj,:)~=1),5);
        x0 = popGen(popSize,lb,ub,minGNPperSC,maxGNPperSC);
        % Log transform r_SC and its bounds for optimization
        x0(:,end) = log10(x0(:,end));
        lb(end) = log10(lb(end));
        ub(end) = log10(ub(end));
        
        % Nonlinear constraint between r_GNP, fillFact, and r_SC
        nlcon = @(x) nonlcon_parEMT(x,[],lb,ub,minGNPperSC,maxGNPperSC);
        
        % Optimize problem
        fval_temp = 1000*ones(popSize,1);
        exitflag_temp = 1000*ones(popSize,1);
        x = zeros(popSize,length(lb));
        options = optimset('AlwaysHonorConstraints','bounds','MaxFunEvals',1e6,'TolFun',TolFun,'TolX',TolX);
        tic
        parfor ii=1:popSize
            t = getCurrentTask();
            % Objective function
            objFcn = @(x) extFcn(lambda,Abs(:,jj),T,x(1),0,x(2),0,eta0,eta1,parA,...
                x(3),x(4),x(5),[lb;ub],fixedParFlag,0,lambdaFloorFit_GEM,lambdaCeilFit_GEM,epsFlag,epsBulkData,parFvalFileName(t.ID,:));

            [x(ii,:),fval_temp(ii),exitflag_temp(ii)] = minimize(objFcn,2*(x0(ii,:)-lb)./(ub-lb)-1,[],[],[],[],...
                -ones(1,length(lb)),ones(1,length(lb)),nlcon,options);
        end
        toc

        % Uncenter, unscale, and take antilog (if applicable)
        x = [(x(:,1:2)+1).*(ub(1:2)-lb(1:2))/2 + lb(1:2),...
            10.^((x(:,end-2:end)+1).*(ub(end-2:end)-lb(end-2:end))/2 + lb(end-2:end))];

        if length(index_fit)==1 % Check the fits one by one
            % Check the optimization results
            subplot = @(m,n,p) subtightplot (m, n, p, [0.1 0.01], [0.1 0.015], [0.1 0.1]);
            figure('Color','white')
            
            subplot(2,3,1)
            plot(x(:,1),fval_temp,'ro')
            xlabel('r_{GNP}')
            ylabel('fval')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            subplot(2,3,2)
            plot(x(:,2),fval_temp,'ro')
            xlabel('\beta')
            ylabel('fval')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            subplot(2,3,3)
            plot(x(:,3),fval_temp,'ro')
            xlabel('x_{SC}')
            ylabel('fval')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            subplot(2,3,4)
            plot(x(:,4),fval_temp,'ro')
            xlabel('filling factor')
            ylabel('fval')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
            subplot(2,3,5)
            plot(x(:,5),fval_temp,'ro')
            xlabel('r_{SC}')
            ylabel('fval')
            axis square
            ylim([min(fval_temp)*0.98, min(fval_temp)*1.1])
        end

        % Extract the optimal values
        [fval_GEM(jj),min_fval_index] = min(fval_temp);
        exitflag_GEM(jj) = exitflag_temp(min_fval_index);
        x = x(min_fval_index,:);
        % Assign to individual variables
        r_GNP_GEM(jj) = x(1);
        beta_GEM(jj) = x(2);
        x_SC(jj) = x(3);
        fillFact(jj) = x(4);
        r_SC(jj) = x(5);
        
        % Check how the calculated spectra looks
        if length(index_fit)==1 % Check the fits one by one
            ax = subplot(2,3,6);
        end
        [deviation_GEM(jj), Abs_calc_GEM(:,jj), concGNP_nM_GEM(jj), concGNP_ppm_GEM(jj), concSC_nM(jj)] = ...
            extFcn(lambda,Abs(:,jj),T,r_GNP_GEM(jj),0,beta_GEM(jj),0,eta0,eta1,parA,...
            x_SC(jj),fillFact(jj),r_SC(jj),[],[],1,lambdaFloorPlot,lambdaCeilPlot,epsFlag,epsBulkData,[]);
        xlim([300,800])
        if length(index_fit)==1 % Check the fits one by one
            xlim([300,800])
            set(ax,'FontSize',18,'FontWeight','bold');
            title(ax,'(f)','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        end
        
        % Calculate ancillary GNP-interaction output
        GNPperSC(jj) = fillFact(jj)*(r_SC(jj)/r_GNP_GEM(jj))^3;
        d_CC(jj) = 2*r_GNP_GEM(jj)*(pi/sqrt(18)/fillFact(jj))^(1/3);
        percGNPinSC(jj) = 100*concSC_nM(jj).*GNPperSC(jj)/concGNP_nM_GEM(jj);
    end
    
    % Extract points within the 95% confidence region
    for ii=1:workerNumber % Combine parFval data
        parFval = [parFval;dlmread(parFvalFileName(ii,:))];
    end
    % fval within confidence region
    iKeep = find(parFval(:,end)/fval_GEM(jj)<=confBound_GEM);
    parFval = parFval(iKeep,:);
    % Convert concGNPandSC_nM data (column 6 of parFval) to concGNP_nM
    parFval(:,6) = parFval(:,6).*(1-parFval(:,3)) + parFval(:,6).*parFval(:,3).*parFval(:,4).*(parFval(:,5)./parFval(:,1)).^3;
    % 95% CIs
    ciPos_GEM(jj,1:6) = max(parFval(:,1:6))-[r_GNP_GEM(jj),beta_GEM(jj),x_SC(jj),fillFact(jj),r_SC(jj),concGNP_nM_GEM(jj)];
    ciNeg_GEM(jj,1:6) = [r_GNP_GEM(jj),beta_GEM(jj),x_SC(jj),fillFact(jj),r_SC(jj),concGNP_nM_GEM(jj)]-min(parFval(:,1:6));
    
    ciPos_GEM(jj,7) = max(parFval(:,6).*6.022e23*19.3*(4/3)*pi.*parFval(:,1).^3*1e-27)-concGNP_ppm_GEM(jj); % 0.01 m path length and bulk density of gold 19.3 g.cm3
    ciNeg_GEM(jj,7) = concGNP_ppm_GEM(jj)-min(parFval(:,6).*6.022e23*19.3*(4/3)*pi.*parFval(:,1).^3*1e-27);
    
    ciPos_GEM(jj,8) = max(parFval(:,6).*parFval(:,3)./(1-parFval(:,3)))-concSC_nM(jj);
    ciNeg_GEM(jj,8) = concSC_nM(jj)-min((parFval(:,6).*parFval(:,3)./(1-parFval(:,3))));
    
    ciPos_GEM(jj,9) = max(parFval(:,4).*(parFval(:,5)./parFval(:,1)).^3)-GNPperSC(jj);
    ciNeg_GEM(jj,9) = GNPperSC(jj)-min(parFval(:,4).*(parFval(:,5)./parFval(:,1)).^3);
    
    ciPos_GEM(jj,10) = max(100.*parFval(:,3).*parFval(:,4).*(parFval(:,5)./parFval(:,1)).^3./((1-parFval(:,3))+parFval(:,3).*parFval(:,4).*(parFval(:,5)./parFval(:,1)).^3))...
        - percGNPinSC(jj);
    ciNeg_GEM(jj,10) = percGNPinSC(jj) - ...
        min(100.*parFval(:,3).*parFval(:,4).*(parFval(:,5)./parFval(:,1)).^3./((1-parFval(:,3))+parFval(:,3).*parFval(:,4).*(parFval(:,5)./parFval(:,1)).^3));
    
    ciPos_GEM(jj,11) = max(2*parFval(:,1).*(pi/sqrt(18)./parFval(:,4)).^(1/3))-d_CC(jj);
    ciNeg_GEM(jj,11) = d_CC(jj)-min(2*parFval(:,1).*(pi/sqrt(18)./parFval(:,4)).^(1/3));
    
    ciPos_GEM(jj,12) = max(2*(pi/sqrt(18)./parFval(:,4)).^(1/3))-d_CC(jj)/r_GNP_GEM(jj);
    ciNeg_GEM(jj,12) = d_CC(jj)/r_GNP_GEM(jj)-min(2*(pi/sqrt(18)./parFval(:,4)).^(1/3));
    
    if length(index_fit)==1 % Check the fits one by one
        % Check the likelihood confidence region results
        figure('Color','white')
        ax = subplot(2,3,1);
        plot(parFval(:,1),parFval(:,end),'ro','MarkerFaceColor','r'); hold on
        plot(r_GNP_GEM(jj),fval_GEM(jj),'ko','MarkerFaceColor','k'); hold off
        xlabel('$\bar{r}_{GNP} (nm)$','Interpreter','Latex','FontWeight','bold')
        ylabel('fval','Interpreter','Latex','FontWeight','bold')
        axis square
        set(ax,'FontSize',18,'FontWeight','bold');
        title(ax,'a','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        ax = subplot(2,3,2);
        plot(parFval(:,2),parFval(:,end),'ro','MarkerFaceColor','r'); hold on
        plot(beta_GEM(jj),fval_GEM(jj),'ko','MarkerFaceColor','k'); hold off
        xlabel('$\bar{\beta}$','Interpreter','Latex','FontWeight','bold')
        ylabel('fval','Interpreter','Latex','FontWeight','bold')
        axis square
        set(ax,'FontSize',18,'FontWeight','bold');
        title(ax,'b','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        ax = subplot(2,3,3);
        plot(parFval(:,3),parFval(:,end),'ro','MarkerFaceColor','r'); hold on
        plot(x_SC(jj),fval_GEM(jj),'ko','MarkerFaceColor','k'); hold off
        xlabel('$x_{SC}$','Interpreter','Latex','FontWeight','bold')
        ylabel('fval','Interpreter','Latex','FontWeight','bold')
        axis square
        set(ax,'FontSize',18,'FontWeight','bold');
        title(ax,'c','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        ax = subplot(2,3,4);
        plot(parFval(:,4),parFval(:,end),'ro','MarkerFaceColor','r'); hold on
        plot(fillFact(jj),fval_GEM(jj),'ko','MarkerFaceColor','k'); hold off
        xlabel('$Filling$ $factor$','Interpreter','Latex','FontWeight','bold')
        ylabel('fval','Interpreter','Latex','FontWeight','bold')
        axis square
        set(ax,'FontSize',18,'FontWeight','bold');
        title(ax,'d','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        ax = subplot(2,3,5);
        plot(parFval(:,5),parFval(:,end),'ro','MarkerFaceColor','r'); hold on
        plot(r_SC(jj),fval_GEM(jj),'ko','MarkerFaceColor','k'); hold off
        xlabel('$r_{SC} (nm)$','Interpreter','Latex','FontWeight','bold')
        ylabel('fval','Interpreter','Latex','FontWeight','bold')
        axis square
        set(ax,'FontSize',18,'FontWeight','bold');
        title(ax,'e','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        ax = subplot(2,3,6);
        plot(parFval(:,6)*6.022e14,parFval(:,end),'ro','MarkerFaceColor','r'); hold on
        plot(concGNP_nM_GEM(jj)*6.022e14,fval_GEM(jj),'ko','MarkerFaceColor','k'); hold off
        xlabel('$c_{GNP} (particles/L)$','Interpreter','Latex','FontWeight','bold')
        ylabel('fval','Interpreter','Latex','FontWeight','bold')
        axis square
        set(ax,'FontSize',18,'FontWeight','bold');
        title(ax,'f','FontSize',18,'FontWeight','bold','Units','normalized','Position',[0.05, 0.9, 1])
        % If you want to save the image uncomment the next 3 lines
        % maximize
        % imagewd = getframe(gcf);
        % imwrite(imagewd.cdata, 'confInterval.tiff','Compression','none','Resolution',600);
    end
    disp(jj)
end

%% Delete unncessary variables
clear ans exitflag_temp fid fval_temp ii jj iKeep lb ub myCluster min_fval_index parFval popSize r_GNP_grown r_GNP_seed ub x x0 parFvalFileName workerNumber parFvalSaveAddress fixedParFlag parCounter searchDomainFlag lb_wideSearch ub_wideSearch ax imagewd
