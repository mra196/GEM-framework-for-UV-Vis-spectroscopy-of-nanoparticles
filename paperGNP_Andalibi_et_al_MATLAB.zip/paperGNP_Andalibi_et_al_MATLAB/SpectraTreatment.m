% This script is for the treatment of the raw spectral data (dark,
% reference, and temporal intensities) and the preparation of input
% extinction spectra for further optimization. This is the very first step
% in the overall protocol for the extraction of the kinetic outputs.
%
% This script is part of the MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling"
% developed by M. Reza Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
% Please cite our article:
% M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".
% 
% % Add path to all necessary folders
% addpath(genpath('...\paperGNP_Andalibi_et_al_MATLAB'));
% % Set the directory
% cd '...\C:\Users\andalibi_m\Dropbox\paperGNP_Andalibi_et_al_MATLAB'
% Load input intensities measured by UV-vis spectroscopy
% load('...input_output\EXP_15-85_70'C\RawSpectra')
% Input timeTiamo, Eh, pH data as well

%% Treatment of raw spectral data and averaging for seeds and grown data
% Set the temperature
T = 273.15 + input('What is the experimnetal temperature (Celcius): ');
% Calculate extinction from reference and dark intensities (water) and sample intensities
Abs = real(log10((Ref-dark)./(intensity-dark)));
% Cut data below 200 nm and above 850 nm
iFloor = find(lambda>=200,1); % Index for floor lambda
iCeil = find(lambda>=850,1); % Index for ceil lambda
lambda = lambda(iFloor:iCeil);
Abs = Abs(iFloor:iCeil,:);

% Replace several seed and final spectra with their average (optional)
numb_seed_Spectra = input('Number of spectra collected before injection (seeds): ');
Abs_seed = mean(Abs(:,1:numb_seed_Spectra),2); % Average several seed spectra
Abs = [Abs_seed,Abs(:,numb_seed_Spectra+1:end)]; % Replace the seed spectra with their average
time = timeInterval*(0:1:size(Abs,2)-1)'; % 0 corresponds to injection (sec)

% Get rid of the second spectrum (overlap with injection moment)
Abs = [Abs(:,1),Abs(:,3:end)];
time = [time(1);time(3:end)];

% Replace several grown GNP spectra with their average (optional)
% % Uncomment the next 7 lines to check how many of the final spectra are similar
% numb_grown_Spectra = 4;
% i400 = find(lambda>=400,1); % Index for lambda = 400 nm
% figure()
% plot(lambda,Abs(:,end-numb_grown_Spectra:end)./max(Abs(i400:end,end-numb_grown_Spectra:end),[],1))
% hold on
% plot(lambda,mean(Abs(:,end-numb_grown_Spectra:end)./max(Abs(i400:end,end-numb_grown_Spectra:end),[],1),2),'k.')
% xlim([300,800])
numb_grown_Spectra = input('Number of spectra considered as grown GNP (similar final spectra): ');
Abs_grown =  mean(Abs(:,end-numb_grown_Spectra+1:end),2); % Average several grown spectra
Abs = [Abs(:,1:end-numb_grown_Spectra),Abs_grown]; % Replace the grown spectra with their average
time = [time(1:end-numb_grown_Spectra);time(end-numb_grown_Spectra+1)]; % 0 corresponds to injection (sec)

%% Removing outliers if present (e.g., detector saturation at some wavelengths), background correction and smoothing the data
% Plot of the original data
figure('Color','White')
subplot(1,2,1);
plot(lambda,Abs)
axis square
subplot(1,2,2);
plot(lambda,Abs(:,1:floor(size(Abs,2)/10):end))
axis square
% Identify the range of lambdas whose Abs are outliers (from the plots above)
lambdaOutlier = input('Enter the range of lambda, as a two element vector, whose corresponding Abs must be removed (outliers): '); % Example: [653.2,658.2] removes all the Abs between these two lambdas
iOutlier = (find(lambda>=lambdaOutlier(1),1):find(lambda>=lambdaOutlier(2),1)); % Extract the indices whose Abs should be removed
lambda(iOutlier) = nan;
iKeep = ~isnan(lambda);
lambda = lambda(iKeep);
Abs = Abs(iKeep,:);
% Plot of the data without outliers
figure('Color','White')
subplot(1,2,1);
plot(lambda,Abs)
axis square
subplot(1,2,2);
plot(lambda,Abs(:,1:floor(size(Abs,2)/10):end),'.')
axis square

% Shift seeds spectrum to ~ 0.02 at 800 (0.01 for seeds and 0.03 for grown spectra)
i798 = find(lambda>=798,1);
i802 = find(lambda>=802,1);
shiftFact_seeds = mean(Abs(i798:i802,1))-input('Extinction at 800 nm for seeds: ');
shiftFact_grown = mean(Abs_grown(i798:i802))-input('Extinction at 800 nm for grown GNP: ');
% Shift spectra with shift factors estimated by lever rule
for jj=1:size(Abs,2)
    Abs(:,jj) = Abs(:,jj) - ((time(end)-time(jj))*shiftFact_seeds + (time(jj)-time(1))*shiftFact_grown) / (time(end)-time(1));
end

% Smooth data with smoothing splines
% Test if smoothing ruins data: before smoothing
plot(lambda,[Abs(:,1:10:length(time)),Abs(:,end)]); hold on;

% Smooth the data using smoothing spline
lambda_temp = (200:1:800)';
Abs_temp = zeros(length(lambda_temp),length(time));
for jj=1:length(time)
    fitresult = fit(lambda, Abs(:,jj), 'smoothingspline' );
    Abs_temp(:,jj) = fitresult(lambda_temp);
end

lambda = lambda_temp;
Abs = Abs_temp;
clear lambda_temp Abs_temp

% Test if smoothing ruins data: after smoothing
plot(lambda,[Abs(:,1:10:length(time)),Abs(:,end)],'o')
axis square

% Replace negative Abs values with zeros
Abs(Abs < 0) = 0;

%% Check some spectral features in the dataset
% Plot selected spectra
figure('Color','white')
rowSubPlot = 5;
colSubPlot = 7;
numbSubPlots = rowSubPlot*colSubPlot;
i=1;
subplot(rowSubPlot,colSubPlot,i)
plot(lambda,Abs(:,1),'k-','LineWidth',1.5)
xlabel('\lambda (nm)')
ylabel('Abs');
title([sprintf('t = %.0f', time(1)), ' sec'])
xlim([300,800])
ylim([0,1.5])
box on
axis square
for i=2:min(numbSubPlots,length(time))-1
    subplot(rowSubPlot,colSubPlot,i)
    plot(lambda,Abs(:,ceil(i*length(time)/numbSubPlots)),'k-','LineWidth',1.5)
    xlabel('\lambda (nm)')
    ylabel('Abs');
    title([sprintf('t = %.0f', time(ceil(i*length(time)/numbSubPlots))), ' sec'])
    xlim([300,800])
    ylim([0,1.5])
    box on
    axis square
end
i = numbSubPlots;
subplot(rowSubPlot,colSubPlot,i)
plot(lambda,Abs(:,length(time)),'k-','LineWidth',1.5)
xlabel('\lambda (nm)')
ylabel('Abs');
title([sprintf('t = %.0f', time(length(time))), ' sec'])
xlim([300,800])
ylim([0,1.5])
box on
axis square

% Plot localized surface plasmon (SPR) position and extinction and Abs_400
i400 = find(lambda>=400,1); % Index for lambda = 400 nm
[Abs_spr,i_spr] = max(Abs(i400:end,:),[],1);
i_spr = i_spr+i400-1;

figure('Color','white')
subplot(1,3,1)
plot(time,lambda(i_spr),'ko')
xlabel('time (sec)')
ylabel('\lambda_{spr}');
box on
axis square
subplot(1,3,2)
plot(time,Abs_spr,'ko')
xlabel('time (sec)')
ylabel('Abs_{spr}');
box on
axis square
subplot(1,3,3)
plot(time,Abs(i400,:),'ko')
xlabel('time (sec)')
ylabel('Abs_{400}');
box on
axis square

% Plot peak-width at half maximum (calculated per: KR Brown, DG Walter, MJ Natan, Chem. Mater. 12.2 (2000): 306-313.)
PWHM = zeros(size(Abs,2),1);
parfor jj=1:size(Abs,2)
	iHM = find(Abs(i_spr(jj):end,jj)<=Abs_spr(jj)/2,1)+i_spr(jj)-1;
	PWHM(jj) = 2*(lambda(iHM)-lambda(i_spr(jj)));
end

figure('Color','white')
plot(time,PWHM,'ko')
xlabel('time (sec)')
ylabel('PWHM (nm)');
box on
axis square

%% Get rid of excessive variables
clearvars -except Abs lambda T time timeTiamo Eh pH
