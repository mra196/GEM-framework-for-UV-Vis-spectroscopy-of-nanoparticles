function pop = popGen(popSize,lb,ub,minGNPperSC,maxGNPperSC)
% 
% This function generates a population of random inital guesses (for global optimization) within the proper bounds and complying with the nonlinear constraint in Supp. Eq. 13 where
% GNPperSC >= minGNPperSC (optionally an upper bound could also be exerted).
% 
% Usage:
% pop = popGen(popSize,lb,ub,minGNPperSC,maxGNPperSC)
% Input:
%   popSize = the number of random points generated as initial guesses
%   lb = lower bound vector for optimization variables
%   ub = upper bound vector for optimization variables
%   minGNPperSC = minimum acceptable number of GNPs interacting inside a SC
%   maxGNPperSC = maximum acceptable number of GNPs interacting inside a SC (set equal to [] if there is none)
% Output:
%   pop = matrix of the initial guesses with each row corresponding to one initial guess and colums dedicated to various variables as [r_GNP,beta,x_SC,f,r_SC]
%
% This function is part of the MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling"
% developed by M. Reza Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
% Please cite our article:
% M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".

% Expand lb and ub to the size of input optimization sets
lb = repmat(lb,popSize,1);
ub = repmat(ub,popSize,1);
% Generate a population of random points within the bounds
pop = lb + rand(popSize,size(lb,2)).*(ub-lb);
fillFact = 10.^pop(:,end-1); % The bounds on x_SC and fillFact are logarithmic (but r_SC here is not log-transformed yet!)
% Nonlinear inequality constraint
if isempty(maxGNPperSC)
    nonlcon_Check = fillFact .* (pop(:,end)./pop(:,1)).^3 < minGNPperSC;
else
    nonlcon_Check = (fillFact .* (pop(:,end)./pop(:,1)).^3 < minGNPperSC) + ...
    (fillFact .* (pop(:,end)./pop(:,1)).^3 > maxGNPperSC);
end
% Replace sets that violate the nonlinear inequality constraint with fresh ones until none of them violate the constraint
while any(nonlcon_Check) % replace any row that violates the constraint
    I = find(nonlcon_Check); % index of the violating rows
    pop(I,:) = lb(I,:) + rand(length(I),size(lb,2)).*(ub(I,:)-lb(I,:));
    fillFact = 10.^pop(:,end-1);
    if isempty(maxGNPperSC)
        nonlcon_Check = fillFact .* (pop(:,end)./pop(:,1)).^3 < minGNPperSC;
    else
        nonlcon_Check = (fillFact .* (pop(:,end)./pop(:,1)).^3 < minGNPperSC) + ...
        (fillFact .* (pop(:,end)./pop(:,1)).^3 > maxGNPperSC);
    end
end