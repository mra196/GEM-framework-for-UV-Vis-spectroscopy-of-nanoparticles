% This script is for the regression of extinction spectra (except for that of seeds and grown GNPS) using the noninteracting GNP model (Gans formalism)
%
% This script is part of the MATLAB workflow on "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling"
% developed by M. Reza Andalibi at Paul Scherrer Institute (PSI)/EPFL (2019).
% Please cite our article:
% M. Reza Andalibi et al., "Kinetics and mechanism of gold nanoparticle growth studied via optical extinction spectroscopy and computational modeling".
% 
% % Add path to all necessary folders
% addpath(genpath('...\paperGNP_Andalibi_et_al_MATLAB'));
% % Set the directory
% cd '...\paperGNP_Andalibi_et_al_MATLAB'
% % Load the file that contains regressions of the seeds and grown GNP spectra
% load('...\input_output\EXP_15-85_70''C\fit_SeedsGrown.mat')
%
% Set up for saving fval and corresponding parameters for 95% confidence bound calculation
myCluster = parcluster('local');
workerNumber = myCluster.NumWorkers; % The number of CPU workers (saving fvals and parameters in separate text files each for one worker)
parFvalSaveAddress = input('Address for saving parFval file: ','s'); % Directory to save the text file (e.g., ...\paperGNP_Andalibi_et_al_MATLAB\input_output\EXP_15-85_70'C\); comment this line if the address is fine
% Spectra to be fitted
index_fit = input('Index of the spectra to be fitted: '); % The index in the time vector, e.g., (2:149) or 35
% Which parameters should be regressed
fixedParFlag = [0,1,0,1,1,1,1]; % Optimize r_GNP and beta

%% Fitting with noninteracting GNP model (Gans theory)
for jj=index_fit
    parFval = [];
    parFvalFileName = [ repmat([parFvalSaveAddress,'parFval'],workerNumber,1),...
        num2str((1:workerNumber)'), repmat('.txt',workerNumber,1) ]; % each worker gets a unique filename
    for ii=1:workerNumber
        fid = fopen(parFvalFileName(ii,:),'w');
        fclose(fid);
    end
    
    lb = [lb_r_GNP,lb_beta]; % lower bound for optimization variables
    ub = [ub_r_GNP,ub_beta]; % upper bound for optimization variables
    
    % Initialize population of random starting points
    popSize = 20;
    x0 = repmat(lb,popSize,1) + ...
        rand(popSize,length(lb)).*repmat(ub-lb,popSize,1);
    % Minimization
    fval_temp = 1000*ones(popSize,1);
    exitflag_temp = 1000*ones(popSize,1);
    x = zeros(popSize,length(lb));
    options = optimset('AlwaysHonorConstraints','bounds','MaxFunEvals',1e6,'TolFun',TolFun,'TolX',TolX);
    tic
    parfor ii=1:popSize
        t = getCurrentTask(); % which worker is running this optimization
        % Objective function
        objFcn = @(x) extFcn(lambda,Abs(:,jj),T,x(1),0,x(2),0,eta0,eta1,parA,...
            0,0,0,[lb;ub],fixedParFlag,0,lambdaFloorFit_GEM,lambdaCeilFit_GEM,epsFlag,epsBulkData,parFvalFileName(t.ID,:));
        
        [x(ii,:),fval_temp(ii),exitflag_temp(ii)] = minimize(objFcn,2*(x0(ii,:)-lb)./(ub-lb)-1,[],[],[],[],...
            -ones(1,length(lb)),ones(1,length(lb)),[],options);
    end
    toc
    % Uncenter and unscale
    x = (x+1).*(ub-lb)/2 + lb;
    % Check the fits one by one
    if length(index_fit)==1
        % Check the optimization results
        figure('Color','white')
        subplot(1,2,1)
        plot(x(:,1),fval_temp,'go')
        xlabel('r_{GNP}')
        ylabel('fval')
        axis square
        subplot(1,2,2)
        plot(x(:,2),fval_temp,'go')
        xlabel('\beta')
        ylabel('fval')
        axis square
    end

    % Extract the optimal values
    [fval_noninteract(jj),min_fval_index] = min(fval_temp);
    exitflag_noninteract(jj) = exitflag_temp(min_fval_index);
    x = x(min_fval_index,:);
    r_GNP_noninteract(jj) = x(1);
    beta_noninteract(jj) = x(2);
    
    % Check how the calculated spectra looks
    if length(index_fit)==1 % Check the fits one by one
        figure('Color','white')
    end
    [deviation_noninteract(jj), Abs_calc_noninteract(:,jj), concGNP_nM_noninteract(jj), concGNP_ppm_noninteract(jj), ~] = ... 
        extFcn(lambda,Abs(:,jj),T,r_GNP_noninteract(jj),0,beta_noninteract(jj),0,eta0,eta1,parA,...
        0,0,0,[],[],1,lambdaFloorPlot,lambdaCeilPlot,epsFlag,epsBulkData,[]);
    xlim([300,800])

    % Extract points within the 95% confidence region
    for ii=1:workerNumber % Combine parFval data
        parFval = [parFval;dlmread(parFvalFileName(ii,:))];
    end
    % fval within confidence region
    iKeep = find(parFval(:,end)/fval_noninteract(jj)<=confBound_noninteract);
    parFval = parFval(iKeep,:);
    % 95% CIs
    ciPos_noninteract(jj,1:2) = max(parFval(:,1:2))-[r_GNP_noninteract(jj),beta_noninteract(jj)];
    ciNeg_noninteract(jj,1:2) = [r_GNP_noninteract(jj),beta_noninteract(jj)]-min(parFval(:,1:2));
    
    ciPos_noninteract(jj,3) = max(parFval(:,6))-concGNP_nM_noninteract(jj);
    ciNeg_noninteract(jj,3) = concGNP_nM_noninteract(jj)-min(parFval(:,6));

    ciPos_noninteract(jj,4) = max(parFval(:,6).*6.022e23*19.3*(4/3)*pi.*parFval(:,1).^3*1e-27)-concGNP_ppm_noninteract(jj);  % 0.01 m path length
    ciNeg_noninteract(jj,4) = concGNP_ppm_noninteract(jj)-min(parFval(:,6).*6.022e23*19.3*(4/3)*pi.*parFval(:,1).^3*1e-27);
    
    if length(index_fit)==1 % Check the fits one by one
        % Check the likelihood confidence region results
        figure('Color','white')
        subplot(2,3,1)
        plot(parFval(:,1),parFval(:,end),'go'); hold on
        plot(r_GNP_noninteract(jj),fval_noninteract(jj),'ko','MarkerFaceColor','w'); hold off
        xlabel('$\bar{r}_{GNP} (nm)$','Interpreter','Latex')
        ylabel('fval','Interpreter','Latex')
        axis square
        subplot(2,3,2)
        plot(parFval(:,2),parFval(:,end),'go'); hold on
        plot(beta_noninteract(jj),fval_noninteract(jj),'ko','MarkerFaceColor','w'); hold off
        xlabel('$\bar{\beta}$','Interpreter','Latex')
        ylabel('fval','Interpreter','Latex')
        axis square
        subplot(2,3,3)
        plot(parFval(:,6),parFval(:,end),'go'); hold on
        plot(concGNP_nM_noninteract(jj),fval_noninteract(jj),'ko','MarkerFaceColor','w'); hold off
        xlabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
        ylabel('fval','Interpreter','Latex')
        axis square
        subplot(2,3,4)
        plot(parFval(:,1),parFval(:,2),'go'); hold on
        plot(r_GNP_noninteract(jj),beta_noninteract(jj),'ko','MarkerFaceColor','w'); hold off
        xlabel('$\bar{r}_{GNP} (nm)$','Interpreter','Latex')
        ylabel('$\bar{\beta}$','Interpreter','Latex')
        axis square
        subplot(2,3,5)
        plot(parFval(:,1),parFval(:,6),'go'); hold on
        plot(r_GNP_noninteract(jj),concGNP_nM_noninteract(jj),'ko','MarkerFaceColor','w'); hold off
        xlabel('$\bar{r}_{GNP} (nm)$','Interpreter','Latex')
        ylabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
        axis square
        subplot(2,3,6)
        plot(parFval(:,2),parFval(:,6),'go'); hold on
        plot(beta_noninteract(jj),concGNP_nM_noninteract(jj),'ko','MarkerFaceColor','w'); hold off
        xlabel('$\bar{\beta}$','Interpreter','Latex')
        ylabel('$c_{GNP} (particles/L)$','Interpreter','Latex')
        axis square
    end
    
    disp(jj)
end

%% Delete unncessary variables
clear ans exitflag_temp fid fval_temp ii jj iKeep lb ub myCluster min_fval_index parFval popSize r_GNP_grown r_GNP_seed ub x x0 parFvalFileName workerNumber parFvalSaveAddress 
